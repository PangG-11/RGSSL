import argparse
import warnings

from train.test import test
from train.train import train

warnings.filterwarnings('ignore')


def build_parser():
    parser = argparse.ArgumentParser(description='TabSSL semi-supervised training')
    parser.add_argument('--mode', type=str, default='train', choices=['train', 'test', 'pretrain'],
                        help='Run mode')

    parser.add_argument('--data', type=str, default='smic_4000',
                        help='Dataset name')

    parser.add_argument('--dim', type=int, default=32, help='Feature dimension')
    parser.add_argument('--depth', type=int, default=6, help='Transformer depth')
    parser.add_argument('--heads', type=int, default=8, help='Number of attention heads')
    parser.add_argument('--dim_head', type=int, default=16, help='Dimension per attention head')
    parser.add_argument('--task_type', type=str, default='auto',
                        choices=['auto', 'regression', 'classification'],
                        help='Task type. auto reads data_processed metadata when available')
    parser.add_argument('--num_classes', type=int, default=None,
                        help='Number of classes for classification')
    parser.add_argument('--dim_out', type=int, default=1,
                        help='Output dimension. Set automatically for classification when metadata is available')
    parser.add_argument('--attn_dropout', type=float, default=0.0, help='Attention dropout')
    parser.add_argument('--ff_dropout', type=float, default=0.0, help='Feed-forward dropout')
    parser.add_argument('--gate_type', type=str, default='headwise',
                        choices=['none', 'headwise', 'elementwise'], help='Attention gate type')
    parser.add_argument('--use_qk_norm', action='store_true', help='Use QK normalization')

    parser.add_argument('--pretrain', type=bool, default=False, help='Use pretrained weights')
    parser.add_argument('--run_pretrain', action='store_true', help='Run pretraining before training')
    parser.add_argument('--p_m', type=float, default=0.1, help='Masking probability')
    parser.add_argument('--alpha', type=float, default=0.01, help='Feature reconstruction loss weight')

    parser.add_argument('--batch_size', type=int, default=100, help='Labeled batch size')
    parser.add_argument('--num_workers', type=int, default=0,
                        help='PyTorch DataLoader workers. Use 0 on Windows for stable tuning runs')
    parser.add_argument('--epochs', type=int, default=200, help='Number of training epochs')
    parser.add_argument('--lr', type=float, default=0.001, help='Learning rate')
    parser.add_argument('--weight_decay', type=float, default=1e-5, help='Weight decay')
    parser.add_argument('--save_interval', type=int, default=10, help='Checkpoint interval')
    parser.add_argument('--unlabeled_ratio', type=int, default=3,
                        help='Unlabeled batch size multiplier')
    parser.add_argument('--consistency_weight', type=float, default=0.2,
                        help='Regression consistency loss weight')
    parser.add_argument('--consistency_rampup', type=int, default=50,
                        help='Epochs used to ramp up consistency weight')
    parser.add_argument('--weak_prediction_number', type=int, default=5,
                        help='Number of stochastic weak-view predictions K')
    parser.add_argument('--tau_u', type=float, default=0.002,
                        help='Uncertainty threshold for unlabeled confidence masking')
    parser.add_argument('--weak_noise_std', type=float, default=0.01,
                        help='Noise scale for weak feature perturbation')
    parser.add_argument('--strong_noise_std', type=float, default=0.05,
                        help='Noise scale for strong feature perturbation')
    parser.add_argument('--noise_type', type=str, default='gaussian',
                        choices=['gaussian', 'uniform', 'bernoulli', 'none'],
                        help='Feature perturbation type')
    parser.add_argument('--consistency_eps', type=float, default=1e-8,
                        help='Small denominator constant for masked consistency loss')
    parser.add_argument('--ema_decay', type=float, default=0.999,
                        help='EMA teacher decay')
    parser.add_argument('--eval_freq', type=int, default=5, help='Evaluation frequency')
    parser.add_argument('--supervised_only', action='store_true',
                        help='Train with labeled data only')
    return parser


if __name__ == '__main__':
    args = build_parser().parse_args()
    if args.mode == 'train':
        train(args)
    elif args.mode == 'test':
        test_metrics = test(args)
        print(f"  Test MSE:   {test_metrics['MSE']:.4f}")
        print(f"  Test MAE:   {test_metrics['MAE']:.4f}")
        print(f"  Test RMSE:  {test_metrics['RMSE']:.4f}")
        print(f"  Test R2:    {test_metrics['R2']:.4f}")
