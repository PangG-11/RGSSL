"""One-command standalone verification for the paper RGSSL implementation."""

import torch
from torch.utils.data import DataLoader as TorchDataLoader

from dataset.dataload import dataset_kwargs_from_args, load_dataset
from main import build_parser
from models.semi_supervised import TabSSL


def main():
    args = build_parser().parse_args([])
    args.data = "Demo"
    args.task_type = "regression"
    args.dim_out = 1

    cat_dims, _, con_idxs, train_set, valid_set, test_set, unlabel_set = load_dataset(
        args.data,
        **dataset_kwargs_from_args(args),
    )
    model = TabSSL(args, cat_dims, len(con_idxs))
    model.train()

    x_cat_l, x_con_l, y_l = next(iter(TorchDataLoader(train_set, batch_size=8)))
    x_cat_u, x_con_u = next(iter(TorchDataLoader(unlabel_set, batch_size=8)))
    prediction = model(x_cat_l.long(), x_con_l.float())
    supervised_loss = torch.mean((prediction - y_l.float()) ** 2)

    with torch.no_grad():
        weak = torch.stack(
            [
                model.get_weak_output(x_cat_u.long(), x_con_u.float())
                for _ in range(args.weak_prediction_number)
            ],
            dim=0,
        )
        pseudo_target = weak.mean(dim=0)
        uncertainty = weak.std(dim=0, unbiased=False)
        mask = (uncertainty <= args.tau_u).float()
    strong = model.get_strong_output(x_cat_u.long(), x_con_u.float())
    consistency_loss = (((strong - pseudo_target) ** 2) * mask).sum() / (mask.sum() + 1e-8)
    total_loss = supervised_loss + args.consistency_weight * consistency_loss
    total_loss.backward()

    inference_parameters = sum(p.numel() for p in model.train_params())
    print("RGSSL standalone smoke test: PASS")
    print(f"  train/valid/unlabeled/test: {len(train_set)}/{len(valid_set)}/{len(unlabel_set)}/{len(test_set)}")
    print(f"  output shape: {tuple(prediction.shape)}")
    print(f"  inference parameters: {inference_parameters:,}")
    print(f"  confidence keep ratio: {mask.mean().item():.3f}")
    print(f"  total loss: {total_loss.item():.6f}")


if __name__ == "__main__":
    main()

