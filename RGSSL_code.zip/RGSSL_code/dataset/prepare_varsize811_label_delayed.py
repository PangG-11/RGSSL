"""Manuscript-named entry point for the label-delayed 25%/75% split."""

try:
    from dataset.prepare_varsize811_label75 import main
except ModuleNotFoundError:
    from prepare_varsize811_label75 import main


if __name__ == "__main__":
    main()
