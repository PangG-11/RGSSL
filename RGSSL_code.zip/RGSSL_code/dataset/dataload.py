from torch.utils.data import Dataset, TensorDataset
import numpy as np
import pandas as pd
try:
    from torchvision import datasets
except ImportError:
    datasets = None
from sklearn.preprocessing import StandardScaler
import os
import json
import torch

from project_paths import DATA_DIR, PROCESSED_DIR, project_path
from dataset.time_split import (
    CHRONOLOGICAL_SEMI_SUPERVISED_STRATEGY,
    chronological_sort,
    chronological_semi_supervised_split,
    resolve_group_column,
)


class DataLoader:
    """Dataset loader."""

    def __init__(self):
        pass

    @staticmethod
    def _create_tensor_datasets(X_train_norm, X_valid_norm, X_test_norm,
                                df_unlabel, cat_idxs, con_idxs,
                                y_train, y_valid, y_test):
        """Create TensorDataset objects."""
        X_train_norm = X_train_norm.values if hasattr(X_train_norm, 'values') else X_train_norm
        X_valid_norm = X_valid_norm.values if hasattr(X_valid_norm, 'values') else X_valid_norm
        X_test_norm = X_test_norm.values if hasattr(X_test_norm, 'values') else X_test_norm

        X_train_cat = torch.tensor(X_train_norm[:, cat_idxs], dtype=torch.long)
        X_train_con = torch.tensor(X_train_norm[:, con_idxs], dtype=torch.float32)
        y_train_tensor = torch.tensor(y_train.values, dtype=torch.float32).view(-1, 1)

        X_valid_cat = torch.tensor(X_valid_norm[:, cat_idxs], dtype=torch.long)
        X_valid_con = torch.tensor(X_valid_norm[:, con_idxs], dtype=torch.float32)
        y_valid_tensor = torch.tensor(y_valid.values, dtype=torch.float32).view(-1, 1)

        X_test_cat = torch.tensor(X_test_norm[:, cat_idxs], dtype=torch.long)
        X_test_con = torch.tensor(X_test_norm[:, con_idxs], dtype=torch.float32)
        y_test_tensor = torch.tensor(y_test.values, dtype=torch.float32).view(-1, 1)

        train_ds = TensorDataset(X_train_cat, X_train_con, y_train_tensor)
        valid_ds = TensorDataset(X_valid_cat, X_valid_con, y_valid_tensor)
        test_ds = TensorDataset(X_test_cat, X_test_con, y_test_tensor)

        X_unlabel = df_unlabel.values if hasattr(df_unlabel, 'values') else df_unlabel
        X_unlabel_cat = torch.tensor(X_unlabel[:, cat_idxs], dtype=torch.long)
        X_unlabel_con = torch.tensor(X_unlabel[:, con_idxs], dtype=torch.float32)
        unlabel_ds = TensorDataset(X_unlabel_cat, X_unlabel_con)

        return train_ds, valid_ds, test_ds, unlabel_ds

    @staticmethod
    def _save_processed_data(save_dir, dataset_name, train_data, valid_data, test_data,
                             df_unlabel, cat_dims, cat_idxs, con_idxs, data_path,
                             split_strategy=CHRONOLOGICAL_SEMI_SUPERVISED_STRATEGY,
                             time_column=None, group_column=None):
        os.makedirs(save_dir, exist_ok=True)

        train_file = f"{save_dir}/{dataset_name}_train.csv"
        valid_file = f"{save_dir}/{dataset_name}_valid.csv"
        test_file = f"{save_dir}/{dataset_name}_test.csv"
        unlabel_file = f"{save_dir}/{dataset_name}_unlabel.csv"
        meta_file = f"{save_dir}/{dataset_name}_meta.json"

        train_data.to_csv(train_file, index=False)
        valid_data.to_csv(valid_file, index=False)
        test_data.to_csv(test_file, index=False)
        df_unlabel.to_csv(unlabel_file, index=False)

        meta = {
            'cat_dims': cat_dims,
            'cat_idxs': cat_idxs,
            'con_idxs': con_idxs,
            'data_shape': {
                'train': train_data.shape,
                'valid': valid_data.shape,
                'test': test_data.shape,
                'unlabel': df_unlabel.shape
            },
            'source_file': data_path,
            'unlabel_processed': True,
            'categorical_encoding': 'train_only_ordinal_unknown_zero',
            'target_scaled': False,
            'target_transform': 'identity',
            'split_strategy': split_strategy,
            'time_column': time_column,
            'group_column': group_column,
        }

        with open(meta_file, 'w') as f:
            json.dump(meta, f, indent=2, default=str)

        print("Saved processed data files")
        print(f"  {train_file}")
        print(f"  {valid_file}")
        print(f"  {test_file}")
        print(f"  {unlabel_file}")
        print(f"  {meta_file}")

        return train_file, valid_file, test_file, unlabel_file, meta_file

    @staticmethod
    def _load_processed_data(save_dir, dataset_name, cat_idxs, con_idxs,
                             required_split_strategy=None):
        train_file = f"{save_dir}/{dataset_name}_train.csv"
        valid_file = f"{save_dir}/{dataset_name}_valid.csv"
        test_file = f"{save_dir}/{dataset_name}_test.csv"
        unlabel_file = f"{save_dir}/{dataset_name}_unlabel.csv"
        meta_file = f"{save_dir}/{dataset_name}_meta.json"

        if (os.path.exists(train_file) and os.path.exists(valid_file) and
                os.path.exists(test_file) and os.path.exists(unlabel_file) and
                os.path.exists(meta_file)):
            print(f"Loading processed data from {save_dir}...")

            with open(meta_file, 'r') as f:
                meta = json.load(f)

            if (required_split_strategy is not None and
                    meta.get('split_strategy') != required_split_strategy):
                print(
                    f"Processed data cache in {save_dir} uses "
                    f"{meta.get('split_strategy', 'an unspecified split')}; "
                    f"expected {required_split_strategy}. Rebuilding is required."
                )
                return None, None, None, None, None, None, None, False

            encoding = meta.get('categorical_encoding')
            supported_encoding = encoding in [
                'joint_label_unlabel',
                'train_only_ordinal_unknown_zero',
                'preprocessed_smic2',
                'batch_processed_smicwat',
                'generic_processed'
            ]
            target_is_valid = (
                meta.get('target_scaled', False)
                or meta.get('target_transform') == 'identity'
                or encoding == 'batch_processed_smicwat'
            )
            if (not meta.get('unlabel_processed', False) or
                    not supported_encoding or
                    not target_is_valid):
                print(f"Processed data cache in {save_dir} is old; rebuilding with scaled unlabeled data...")
                return None, None, None, None, None, None, None, False

            train_data = pd.read_csv(train_file)
            valid_data = pd.read_csv(valid_file)
            test_data = pd.read_csv(test_file)
            df_unlabel = pd.read_csv(unlabel_file)

            cat_dims = meta['cat_dims']
            cat_idxs = meta['cat_idxs']
            con_idxs = meta['con_idxs']

            X_train_cat = torch.tensor(train_data.iloc[:, cat_idxs].values, dtype=torch.long)
            X_train_con = torch.tensor(train_data.iloc[:, con_idxs].values, dtype=torch.float32)
            y_train = torch.tensor(train_data.iloc[:, -1].values, dtype=torch.float32).view(-1, 1)
            train_ds = TensorDataset(X_train_cat, X_train_con, y_train)

            X_valid_cat = torch.tensor(valid_data.iloc[:, cat_idxs].values, dtype=torch.long)
            X_valid_con = torch.tensor(valid_data.iloc[:, con_idxs].values, dtype=torch.float32)
            y_valid = torch.tensor(valid_data.iloc[:, -1].values, dtype=torch.float32).view(-1, 1)
            valid_ds = TensorDataset(X_valid_cat, X_valid_con, y_valid)

            X_test_cat = torch.tensor(test_data.iloc[:, cat_idxs].values, dtype=torch.long)
            X_test_con = torch.tensor(test_data.iloc[:, con_idxs].values, dtype=torch.float32)
            y_test = torch.tensor(test_data.iloc[:, -1].values, dtype=torch.float32).view(-1, 1)
            test_ds = TensorDataset(X_test_cat, X_test_con, y_test)

            if len(df_unlabel) == 0:
                X_unlabel_cat = torch.empty((0, len(cat_idxs)), dtype=torch.long)
                X_unlabel_con = torch.empty((0, len(con_idxs)), dtype=torch.float32)
            else:
                X_unlabel_cat = torch.tensor(df_unlabel.iloc[:, cat_idxs].values, dtype=torch.long)
                X_unlabel_con = torch.tensor(df_unlabel.iloc[:, con_idxs].values, dtype=torch.float32)
            unlabel_ds = TensorDataset(X_unlabel_cat, X_unlabel_con)

            print("Loaded processed data")
            print(f"  Train: {len(train_ds)} samples")
            print(f"  Valid: {len(valid_ds)} samples")
            print(f"  Test: {len(test_ds)} samples")
            print(f"  Unlabeled: {len(unlabel_ds)} samples")
            print(f"  Categorical dimensions: {cat_dims}")

            return cat_dims, cat_idxs, con_idxs, train_ds, valid_ds, test_ds, unlabel_ds, True

        return None, None, None, None, None, None, None, False

    def _process_dataset(self, df, target_col, label_size, unlabel_size,
                         save_dir, dataset_name, data_path,
                         process_target_func=None, time_col=None,
                         group_col="LOT_ID", valid_size=None, test_size=None):
        """Process a tabular dataset."""
        result = self._load_processed_data(
            save_dir,
            dataset_name,
            [],
            [],
            required_split_strategy=CHRONOLOGICAL_SEMI_SUPERVISED_STRATEGY,
        )
        if result[-1]:
            return result[:-1]

        print("Processed cache not found; processing raw data...")

        resolved_group_col = resolve_group_column(df, group_col)
        if (resolved_group_col is None and group_col and
                str(group_col).lower() == "lot_id" and "WAFER_ID" in df.columns):
            # SMIC stores IDs as <LOT>_<WAFER_NO> (for example HKU101_1).
            # Recover the LOT key before removing WAFER_ID from model features.
            df = df.copy()
            df["LOT_ID"] = df["WAFER_ID"].astype(str).str.rsplit("_", n=1).str[0]
            resolved_group_col = "LOT_ID"

        df, resolved_time_col = chronological_sort(df, time_col)
        if resolved_time_col is not None:
            # The time field defines the split boundary and is not a model feature.
            df = df.drop(columns=[resolved_time_col])
        if 'WAFER_ID' in df.columns:
            df = df.drop(columns=['WAFER_ID'])

        train_raw, valid_raw, df_unlabel, test_raw = (
            chronological_semi_supervised_split(
                df,
                label_size=label_size,
                unlabel_size=unlabel_size,
                valid_size=valid_size,
                test_size=test_size,
                group_column=resolved_group_col,
            )
        )
        split_frames = [train_raw, valid_raw, df_unlabel, test_raw]
        if resolved_group_col is not None:
            # LOT identifiers define split membership but are not WAT predictors.
            split_frames = [
                frame.drop(columns=[resolved_group_col], errors='ignore')
                for frame in split_frames
            ]
        train_raw, valid_raw, df_unlabel, test_raw = [
            frame.reset_index(drop=True) for frame in split_frames
        ]

        for labeled_frame in [train_raw, valid_raw, test_raw]:
            if process_target_func and target_col in labeled_frame.columns:
                process_target_func(labeled_frame, target_col)

        y_train = train_raw[target_col].copy()
        y_valid = valid_raw[target_col].copy()
        y_test = test_raw[target_col].copy()
        X_train = train_raw.drop(columns=[target_col]).copy()
        X_valid = valid_raw.drop(columns=[target_col]).copy()
        X_test = test_raw.drop(columns=[target_col]).copy()
        X_unlabel = df_unlabel.drop(columns=[target_col], errors='ignore').copy()

        features = list(X_train.columns)
        categorical_columns = [col for col in features if X_train[col].dtype == object]
        continuous_columns = [col for col in features if col not in categorical_columns]
        cat_idxs = [features.index(col) for col in categorical_columns]
        con_idxs = [features.index(col) for col in continuous_columns]

        # Fit categorical mappings on labeled training data only. Index 0 is
        # reserved for missing or previously unseen categories.
        category_maps = {}
        cat_dims = []
        for col in categorical_columns:
            train_values = X_train[col].fillna("__MISSING__").astype(str)
            classes = list(pd.unique(train_values))
            mapping = {value: index + 1 for index, value in enumerate(classes)}
            category_maps[col] = mapping
            cat_dims.append(len(mapping) + 1)

        def encode_categories(frame):
            encoded = pd.DataFrame(index=frame.index)
            for col in categorical_columns:
                values = frame[col].fillna("__MISSING__").astype(str)
                encoded[col] = values.map(category_maps[col]).fillna(0).astype(int)
            return encoded

        X_train_cat = encode_categories(X_train)
        X_valid_cat = encode_categories(X_valid)
        X_test_cat = encode_categories(X_test)
        df_unlabel_cat = encode_categories(X_unlabel)

        # The manuscript fits median imputation and standardization using only
        # the labeled training subset, then applies that pipeline unchanged.
        if continuous_columns:
            medians = X_train[continuous_columns].median(numeric_only=True).reindex(
                continuous_columns
            ).fillna(0.0)
            X_train_con_raw = X_train[continuous_columns].fillna(medians)
            X_valid_con_raw = X_valid[continuous_columns].fillna(medians)
            X_test_con_raw = X_test[continuous_columns].fillna(medians)
            X_unlabel_con_raw = X_unlabel[continuous_columns].fillna(medians)

            scaler = StandardScaler()
            X_train_con = pd.DataFrame(
                scaler.fit_transform(X_train_con_raw),
                columns=continuous_columns,
                index=X_train.index,
            )
            X_valid_con = pd.DataFrame(
                scaler.transform(X_valid_con_raw),
                columns=continuous_columns,
                index=X_valid.index,
            )
            X_test_con = pd.DataFrame(
                scaler.transform(X_test_con_raw),
                columns=continuous_columns,
                index=X_test.index,
            )
            df_unlabel_con = pd.DataFrame(
                scaler.transform(X_unlabel_con_raw),
                columns=continuous_columns,
                index=X_unlabel.index,
            )
        else:
            X_train_con = pd.DataFrame(index=X_train.index)
            X_valid_con = pd.DataFrame(index=X_valid.index)
            X_test_con = pd.DataFrame(index=X_test.index)
            df_unlabel_con = pd.DataFrame(index=X_unlabel.index)

        # Restore the original feature order after separately encoding categorical
        # columns and scaling continuous columns. This keeps cat_idxs/con_idxs and
        # saved CSV column names aligned even when feature types are interleaved.
        X_train_processed = pd.concat([X_train_cat, X_train_con], axis=1).reindex(columns=features)
        X_valid_processed = pd.concat([X_valid_cat, X_valid_con], axis=1).reindex(columns=features)
        X_test_processed = pd.concat([X_test_cat, X_test_con], axis=1).reindex(columns=features)
        df_unlabel_processed = pd.concat(
            [df_unlabel_cat, df_unlabel_con], axis=1
        ).reindex(columns=features)
        train_data = pd.DataFrame(
            np.hstack([X_train_processed.values, y_train.values.reshape(-1, 1)]),
            columns=features + [target_col]
        )

        valid_data = pd.DataFrame(
            np.hstack([X_valid_processed.values, y_valid.values.reshape(-1, 1)]),
            columns=features + [target_col]
        )

        test_data = pd.DataFrame(
            np.hstack([X_test_processed.values, y_test.values.reshape(-1, 1)]),
            columns=features + [target_col]
        )

        self._save_processed_data(save_dir, dataset_name, train_data, valid_data,
                                  test_data, df_unlabel_processed, cat_dims, cat_idxs,
                                  con_idxs, data_path,
                                  split_strategy=CHRONOLOGICAL_SEMI_SUPERVISED_STRATEGY,
                                  time_column=resolved_time_col,
                                  group_column=resolved_group_col)

        train_ds, valid_ds, test_ds, unlabel_ds = self._create_tensor_datasets(
            X_train_processed, X_valid_processed, X_test_processed, df_unlabel_processed,
            cat_idxs, con_idxs, y_train, y_valid, y_test
        )

        print("Processed data")
        print(f"  Train: {len(train_ds)} samples")
        print(f"  Valid: {len(valid_ds)} samples")
        print(f"  Test: {len(test_ds)} samples")
        print(f"  Unlabeled: {len(unlabel_ds)} samples")
        print(f"  Categorical dimensions: {cat_dims}")

        return cat_dims, cat_idxs, con_idxs, train_ds, valid_ds, test_ds, unlabel_ds

    def load_icsprout(self, data_path=None, time_col=None,
                      group_col="LOT_ID"):
        """Load ICSprout."""
        data_path = project_path(data_path) if data_path else DATA_DIR / "data_789(boruta).csv"
        save_dir = PROCESSED_DIR / "icsprout"
        dataset_name = "icsprout"

        df = pd.read_csv(data_path)

        def process_yield(df_label, target_col):
            # Keep CP yield on the manuscript's 0-100 percentage scale.
            return df_label

        return self._process_dataset(
            df=df,
            target_col="yield",
            label_size=1256,
            unlabel_size=1000,
            save_dir=save_dir,
            dataset_name=dataset_name,
            data_path=data_path,
            process_target_func=process_yield,
            time_col=time_col,
            group_col=group_col,
        )

    def load_smic(self, data_path=None, save_dir=None,
                  label_size=3000, unlabel_size=10000, time_col=None,
                  group_col="LOT_ID", valid_size=None, test_size=None):
        """Load SMIC."""
        dataset_name = "smic"
        data_path = project_path(data_path) if data_path else DATA_DIR / "smic.csv"
        save_dir = project_path(save_dir) if save_dir else PROCESSED_DIR / "smic"

        df = pd.read_csv(data_path)

        def process_yield(df_label, target_col):
            # Keep CP yield on the manuscript's 0-100 percentage scale.
            return df_label

        return self._process_dataset(
            df=df,
            target_col="yield",
            label_size=label_size,
            unlabel_size=unlabel_size,
            save_dir=save_dir,
            dataset_name=dataset_name,
            data_path=data_path,
            process_target_func=process_yield,
            time_col=time_col,
            group_col=group_col,
            valid_size=valid_size,
            test_size=test_size,
        )
    def load_smic_4000(self, data_path=None, save_dir=None,
                  label_size=1000, unlabel_size=3000, time_col=None,
                  group_col="LOT_ID", valid_size=None, test_size=None):
        """Load SMIC 4000."""
        dataset_name = "smic_4000"
        data_path = project_path(data_path) if data_path else DATA_DIR / "smic.csv"
        save_dir = project_path(save_dir) if save_dir else PROCESSED_DIR / "smic_4000"

        df = pd.read_csv(data_path)

        def process_yield(df_label, target_col):
            # Keep CP yield on the manuscript's 0-100 percentage scale.
            return df_label

        return self._process_dataset(
            df=df,
            target_col="yield",
            label_size=label_size,
            unlabel_size=unlabel_size,
            save_dir=save_dir,
            dataset_name=dataset_name,
            data_path=data_path,
            process_target_func=process_yield,
            time_col=time_col,
            group_col=group_col,
            valid_size=valid_size,
            test_size=test_size,
        )

    def load_processed_smic2(self, dataset_name):
        """Load a preprocessed SMIC2 split."""
        save_dir = PROCESSED_DIR / dataset_name
        result = self._load_processed_data(
            save_dir, dataset_name, [], [],
            required_split_strategy=CHRONOLOGICAL_SEMI_SUPERVISED_STRATEGY,
        )
        if result[-1]:
            return result[:-1]
        raise FileNotFoundError(
            f"Processed SMIC2 split not found or invalid: {save_dir}. "
            "Run dataset/prepare_smic2_ratios.py first."
        )

    def load_processed_split(self, dataset_name):
        """Load a processed split generated by a batch experiment script."""
        save_dir = PROCESSED_DIR / dataset_name
        result = self._load_processed_data(
            save_dir, dataset_name, [], [],
            required_split_strategy=CHRONOLOGICAL_SEMI_SUPERVISED_STRATEGY,
        )
        if result[-1]:
            return result[:-1]
        raise FileNotFoundError(
            f"Processed split not found or invalid: {save_dir}. "
            "Run the corresponding preparation script first."
        )

    def load_htsga18(self, data_path=None, time_col=None,
                     group_col="LOT_ID"):
        """Load HTSGA18."""
        data_path = project_path(data_path) if data_path else DATA_DIR / "HTSGA18_processed.csv"
        save_dir = PROCESSED_DIR / "htsga18"
        dataset_name = "htsga18"

        df = pd.read_csv(data_path)

        df = df.iloc[:, 6:]

        return self._process_dataset(
            df=df,
            target_col="BTH",
            label_size=3000,
            unlabel_size=len(df) - 3000,
            save_dir=save_dir,
            dataset_name=dataset_name,
            data_path=data_path,
            time_col=time_col,
            group_col=group_col,
        )

    def load_mnist(self, label_data_number=1000, unlab_data_number=5000, data_dir='data'):
        """Load MNIST as tabular data."""
        if datasets is None:
            raise ImportError("torchvision is required to load MNIST")
        data_dir = project_path(data_dir)
        save_dir = PROCESSED_DIR / "mnist"
        dataset_name = "mnist"

        result = self._load_processed_data(
            save_dir, dataset_name, [], [],
            required_split_strategy=CHRONOLOGICAL_SEMI_SUPERVISED_STRATEGY,
        )
        if result[-1]:
            return result[:-1]

        print("Processed cache not found; processing raw data...")

        train_dataset = datasets.MNIST(root=data_dir, train=True, download=True)
        test_dataset = datasets.MNIST(root=data_dir, train=False, download=True)

        x_train, y_train = train_dataset._load_data()
        x_test, y_test = test_dataset._load_data()

        x_train = x_train.numpy()
        y_train = y_train.numpy()
        x_test = x_test.numpy()
        y_test = y_test.numpy()

        x_train = x_train / 255.0
        x_test = x_test / 255.0

        x_train = x_train.reshape(-1, 28 * 28)
        x_test = x_test.reshape(-1, 28 * 28)

        feature_cols = [f'pixel_{i}' for i in range(784)]

        df_train = pd.DataFrame(x_train, columns=feature_cols)
        df_test = pd.DataFrame(x_test, columns=feature_cols)

        y_train_df = pd.DataFrame(y_train, columns=['label'])
        y_test_df = pd.DataFrame(y_test, columns=['label'])

        df_label_train = pd.concat([df_train, y_train_df], axis=1)
        df_label_test = pd.concat([df_test, y_test_df], axis=1)

        # MNIST has no timestamp; preserve source order instead of random splitting.
        label_idx = np.arange(label_data_number)
        unlab_idx = np.arange(
            label_data_number,
            label_data_number + unlab_data_number,
        )

        df_label = df_label_train.iloc[label_idx].reset_index(drop=True)

        df_unlabel = df_train.iloc[unlab_idx].reset_index(drop=True)

        df_test = df_label_test.reset_index(drop=True)

        cat_idxs = []
        con_idxs = list(range(784))
        cat_dims = []

        X = df_label.iloc[:, :-1]
        y = df_label.iloc[:, -1]

        train_end = max(1, min(int(len(X) * 0.8), len(X) - 1))
        X_train = X.iloc[:train_end].copy()
        X_valid = X.iloc[train_end:].copy()
        y_train = y.iloc[:train_end].copy()
        y_valid = y.iloc[train_end:].copy()

        scaler = StandardScaler()
        X_train_norm = scaler.fit_transform(X_train)
        X_valid_norm = scaler.transform(X_valid)
        X_test_norm = scaler.transform(df_test.iloc[:, :-1])

        train_data = pd.DataFrame(
            np.hstack([X_train_norm, y_train.values.reshape(-1, 1)]),
            columns=feature_cols + ['label']
        )

        valid_data = pd.DataFrame(
            np.hstack([X_valid_norm, y_valid.values.reshape(-1, 1)]),
            columns=feature_cols + ['label']
        )

        test_data = pd.DataFrame(
            np.hstack([X_test_norm, df_test.iloc[:, -1].values.reshape(-1, 1)]),
            columns=feature_cols + ['label']
        )

        self._save_processed_data(save_dir, dataset_name, train_data, valid_data,
                                  test_data, df_unlabel, cat_dims, cat_idxs,
                                  con_idxs, "MNIST")

        X_train_con = torch.tensor(X_train_norm, dtype=torch.float32)
        y_train_tensor = torch.tensor(y_train.values, dtype=torch.float32).view(-1, 1)

        X_valid_con = torch.tensor(X_valid_norm, dtype=torch.float32)
        y_valid_tensor = torch.tensor(y_valid.values, dtype=torch.float32).view(-1, 1)

        X_test_con = torch.tensor(X_test_norm, dtype=torch.float32)
        y_test_tensor = torch.tensor(df_test.iloc[:, -1].values, dtype=torch.float32).view(-1, 1)

        train_ds = TensorDataset(torch.zeros(len(X_train_con), 0, dtype=torch.long),
                                 X_train_con, y_train_tensor)
        valid_ds = TensorDataset(torch.zeros(len(X_valid_con), 0, dtype=torch.long),
                                 X_valid_con, y_valid_tensor)
        test_ds = TensorDataset(torch.zeros(len(X_test_con), 0, dtype=torch.long),
                                X_test_con, y_test_tensor)

        X_unlabel_norm = scaler.transform(df_unlabel)
        X_unlabel_con = torch.tensor(X_unlabel_norm, dtype=torch.float32)
        unlabel_ds = TensorDataset(torch.zeros(len(X_unlabel_con), 0, dtype=torch.long),
                                   X_unlabel_con)

        print("Processed data")
        print(f"  Train: {len(train_ds)} samples")
        print(f"  Valid: {len(valid_ds)} samples")
        print(f"  Test: {len(test_ds)} samples")
        print(f"  Unlabeled: {len(unlabel_ds)} samples")
        print(f"  Categorical dimensions: {cat_dims}")

        return cat_dims, cat_idxs, con_idxs, train_ds, valid_ds, test_ds, unlabel_ds

    def load_csv(self, data_path, target_col="yield", dataset_name="custom_csv",
                 save_dir=None, label_size=1000, unlabel_size=3000,
                 valid_size=None, test_size=None, time_col=None,
                 group_col="LOT_ID"):
        """Load a manuscript-style CSV without relying on repository-specific names."""
        if not data_path:
            raise ValueError("CSV mode requires --data_path")
        data_path = project_path(data_path)
        save_dir = (
            project_path(save_dir)
            if save_dir
            else PROCESSED_DIR / dataset_name
        )
        df = pd.read_csv(data_path)
        if target_col not in df.columns:
            raise ValueError(
                f"Target column {target_col!r} was not found in {data_path}"
            )
        return self._process_dataset(
            df=df,
            target_col=target_col,
            label_size=label_size,
            unlabel_size=unlabel_size,
            valid_size=valid_size,
            test_size=test_size,
            save_dir=save_dir,
            dataset_name=dataset_name,
            data_path=str(data_path),
            time_col=time_col,
            group_col=group_col,
        )

    def load_demo(self, save_dir=None, time_col="CP_COMPLETION_TIME",
                  group_col="LOT_ID", seed=42, **_):
        """Generate a small deterministic dataset for standalone smoke testing."""
        rng = np.random.default_rng(seed)
        lot_count = 40
        wafers_per_lot = 8
        row_count = lot_count * wafers_per_lot
        continuous = rng.normal(size=(row_count, 16))
        missing = rng.random(continuous.shape) < 0.02
        continuous[missing] = np.nan
        frame = pd.DataFrame(
            continuous,
            columns=[f"WAT_{index:02d}" for index in range(16)],
        )
        frame.insert(0, "RECIPE", [f"R{index % 3}" for index in range(row_count)])
        frame.insert(0, "PRODUCT_ID", [f"P{index % 2}" for index in range(row_count)])
        frame.insert(0, "WAFER_ID", [
            f"LOT{index // wafers_per_lot:03d}_{index % wafers_per_lot + 1}"
            for index in range(row_count)
        ])
        frame.insert(0, "LOT_ID", [
            f"LOT{index // wafers_per_lot:03d}" for index in range(row_count)
        ])
        frame.insert(
            0,
            "CP_COMPLETION_TIME",
            pd.date_range("2025-01-01", periods=row_count, freq="h"),
        )
        signal = np.nan_to_num(continuous[:, :4], nan=0.0).sum(axis=1)
        frame["yield"] = np.clip(90.0 + signal + rng.normal(0, 0.5, row_count), 0, 100)
        save_dir = project_path(save_dir) if save_dir else PROCESSED_DIR / "demo"
        return self._process_dataset(
            df=frame,
            target_col="yield",
            label_size=64,
            unlabel_size=192,
            valid_size=32,
            test_size=32,
            save_dir=save_dir,
            dataset_name="demo",
            data_path="generated_demo",
            time_col=time_col,
            group_col=group_col,
        )


def dataset_kwargs_from_args(args):
    """Build only the loader arguments relevant to the selected dataset."""
    data_name = str(getattr(args, 'data', '')).lower()
    values = {
        'time_col': getattr(args, 'time_column', None),
        'group_col': getattr(args, 'group_column', 'LOT_ID'),
    }
    if data_name in {'csv', 'custom_csv'}:
        values.update({
            'data_path': getattr(args, 'data_path', None),
            'target_col': getattr(args, 'target_col', 'yield'),
            'dataset_name': getattr(args, 'dataset_name', 'custom_csv'),
            'save_dir': getattr(args, 'processed_dir', None),
            'label_size': getattr(args, 'label_size', 1000),
            'unlabel_size': getattr(args, 'unlabel_size', 3000),
            'valid_size': getattr(args, 'valid_size', None),
            'test_size': getattr(args, 'test_size', None),
        })
    elif data_name in {'smic', 'smic_4000'}:
        values.update({
            'data_path': getattr(args, 'data_path', None),
            'save_dir': getattr(args, 'processed_dir', None),
            'label_size': getattr(args, 'label_size', None),
            'unlabel_size': getattr(args, 'unlabel_size', None),
            'valid_size': getattr(args, 'valid_size', None),
            'test_size': getattr(args, 'test_size', None),
        })
    elif data_name == 'demo':
        values.update({
            'save_dir': getattr(args, 'processed_dir', None),
            'seed': getattr(args, 'seed', 42),
        })
    return {key: value for key, value in values.items() if value is not None}


def load_dataset(data_name, **kwargs):
    """Load a supported dataset."""
    loader = DataLoader()
    time_col = kwargs.pop('time_col', None)
    group_col = kwargs.pop('group_col', 'LOT_ID')

    if data_name.lower() == 'demo':
        return loader.load_demo(time_col=time_col or "CP_COMPLETION_TIME",
                                group_col=group_col, **kwargs)
    if data_name.lower() in {'csv', 'custom_csv'}:
        return loader.load_csv(time_col=time_col, group_col=group_col, **kwargs)

    if data_name == 'ICSprout':
        return loader.load_icsprout(time_col=time_col, group_col=group_col, **kwargs)
    elif data_name == 'SMIC':
        return loader.load_smic(time_col=time_col, group_col=group_col, **kwargs)
    elif data_name == 'HTSGA18':
        return loader.load_htsga18(time_col=time_col, group_col=group_col, **kwargs)
    elif data_name == 'MNIST':
        return loader.load_mnist(**kwargs)
    elif data_name == 'smic_4000':
        return loader.load_smic_4000(time_col=time_col, group_col=group_col, **kwargs)
    elif data_name in ['smic2_5', 'smic2_50', 'smic2_100']:
        return loader.load_processed_smic2(data_name)
    elif data_name.startswith('smicwat_') or (PROCESSED_DIR / data_name).is_dir():
        return loader.load_processed_split(data_name)
    else:
        raise ValueError(f"Unknown dataset name: {data_name}")


def data_mask_split(X, y, mask, y_mask, indices, mask_det, stage):
    try:
        x_d = {
            'data': X.values[indices],
            'mask': mask.values[indices]
        }
    except:
        x_d = {
            'data': X.values[indices],
            'mask': mask[indices]
        }

    if y is not None:
        y_d = {
            'data': y.values[indices].reshape(-1, 1),
            'mask': y_mask[indices].reshape(-1, 1)
        }
    else:
        y_d = None

    if mask_det is not None:
        if stage == 'train' and mask_det['avail_train_y'] > 0:
            avail_ys = np.random.choice(y_d['mask'].shape[0], mask_det['avail_train_y'], replace=False)
            y_d['mask'][avail_ys, :] = 1

        if stage != 'train' and mask_det['test_mask'] < 10e-3:
            x_d['mask'] = np.ones_like(x_d['mask'])

    return x_d, y_d


