"""Utilities for leakage-safe chronological dataset splitting."""

from __future__ import annotations

import warnings

import numpy as np
import pandas as pd


DEFAULT_TIME_COLUMNS = (
    "CP_COMPLETION_TIME",
    "CP_COMPLETE_TIME",
    "CP_END_TIME",
    "START_TIME",
    "LOAD_TIME",
    "TEST_DAY",
    "timestamp",
    "datetime",
    "date",
    "time",
)

CHRONOLOGICAL_SEMI_SUPERVISED_STRATEGY = (
    "chronological_lot_grouped_label_delayed_25_75_train_valid_unlabeled_test"
)

DEFAULT_GROUP_COLUMNS = ("LOT_ID", "LOT")


def resolve_time_column(df: pd.DataFrame, time_column: str | None = None) -> str | None:
    """Resolve an explicit or conventional time column, case-insensitively."""
    by_lower = {str(column).lower(): column for column in df.columns}

    if time_column:
        resolved = by_lower.get(time_column.lower())
        if resolved is None:
            raise ValueError(
                f"Time column {time_column!r} was not found. "
                f"Available columns: {list(df.columns)}"
            )
        return resolved

    for candidate in DEFAULT_TIME_COLUMNS:
        resolved = by_lower.get(candidate.lower())
        if resolved is not None:
            return resolved
    return None


def resolve_group_column(
    df: pd.DataFrame,
    group_column: str | None = "LOT_ID",
) -> str | None:
    """Resolve a LOT/group column case-insensitively.

    An explicit column that is not present falls back to conventional LOT
    column names. This keeps datasets without LOT information usable while the
    split strategy remains deterministic.
    """
    by_lower = {str(column).lower(): column for column in df.columns}
    if group_column:
        resolved = by_lower.get(group_column.lower())
        if resolved is not None:
            return resolved

    for candidate in DEFAULT_GROUP_COLUMNS:
        resolved = by_lower.get(candidate.lower())
        if resolved is not None:
            return resolved
    return None


def chronological_sort(
    df: pd.DataFrame,
    time_column: str | None = None,
) -> tuple[pd.DataFrame, str | None]:
    """Return rows in ascending time order using a stable sort.

    If no time column is present, source row order is preserved.  This fallback
    is deterministic and intentionally never shuffles the data.
    """
    resolved = resolve_time_column(df, time_column)
    if resolved is None:
        warnings.warn(
            "No time column was found; preserving source row order for the "
            "chronological split. Pass --time_column to enforce a specific column.",
            RuntimeWarning,
            stacklevel=2,
        )
        return df.reset_index(drop=True), None

    parsed_time = pd.to_datetime(df[resolved], errors="coerce")
    if not parsed_time.notna().any():
        raise ValueError(f"Time column {resolved!r} contains no parseable timestamps")

    ordered = df.copy()
    ordered["__split_time"] = parsed_time
    ordered["__source_order"] = np.arange(len(ordered))
    ordered = ordered.sort_values(
        ["__split_time", "__source_order"],
        kind="mergesort",
        na_position="last",
    )
    ordered = ordered.drop(columns=["__split_time", "__source_order"])
    return ordered.reset_index(drop=True), resolved


def chronological_grouped_block_split(
    df: pd.DataFrame,
    target_counts,
    group_column: str | None = "LOT_ID",
):
    """Split ordered rows into adjacent blocks without breaking LOT groups.

    ``target_counts`` contains the desired row count for each block. With a LOT
    column, each boundary is moved to the nearest feasible complete-LOT
    boundary, so returned sizes can differ slightly from the requested values.
    """
    target_counts = [int(count) for count in target_counts]
    if not target_counts or any(count < 0 for count in target_counts):
        raise ValueError("target_counts must contain non-negative integers")
    required_rows = sum(target_counts)
    if len(df) < required_rows:
        raise ValueError(
            f"Chronological split requires {required_rows} rows, but only "
            f"{len(df)} are available"
        )

    resolved_group = resolve_group_column(df, group_column)
    if resolved_group is None:
        warnings.warn(
            "No LOT/group column was found; falling back to row-level "
            "chronological split.",
            RuntimeWarning,
            stacklevel=2,
        )
        boundaries = np.cumsum([0] + target_counts)
        return [
            df.iloc[boundaries[index]:boundaries[index + 1]].copy().reset_index(drop=True)
            for index in range(len(target_counts))
        ]

    # Keep missing LOT values independent instead of treating all missing rows
    # as one artificial, potentially very large LOT.
    group_keys = df[resolved_group].astype("object").copy()
    missing = group_keys.isna()
    if missing.any():
        group_keys.loc[missing] = [
            f"__missing_lot_row_{index}" for index in df.index[missing]
        ]

    lot_codes, _ = pd.factorize(group_keys, sort=False)
    lot_frames = [
        df.loc[lot_codes == code].copy()
        for code in range(int(lot_codes.max()) + 1)
    ]
    lot_count = len(lot_frames)
    minimum_lots = sum(count > 0 for count in target_counts)
    if lot_count < minimum_lots:
        raise ValueError(
            f"LOT-grouped split needs at least {minimum_lots} distinct LOTs, "
            f"but found {lot_count} in {resolved_group!r}"
        )

    cumulative_rows = np.concatenate(
        ([0], np.cumsum([len(frame) for frame in lot_frames]))
    )

    def nearest_lot_boundary(target, minimum, maximum):
        candidates = np.arange(minimum, maximum + 1)
        distances = np.abs(cumulative_rows[candidates] - target)
        return int(candidates[int(np.argmin(distances))])

    boundaries = [0]
    cumulative_target = 0
    for index, target_count in enumerate(target_counts):
        cumulative_target += target_count
        if target_count == 0:
            boundaries.append(boundaries[-1])
            continue
        remaining_nonempty = sum(count > 0 for count in target_counts[index + 1:])
        boundaries.append(
            nearest_lot_boundary(
                cumulative_target,
                boundaries[-1] + 1,
                lot_count - remaining_nonempty,
            )
        )

    def combine_lots(start, end):
        if start == end:
            return df.iloc[0:0].copy().reset_index(drop=True)
        return pd.concat(lot_frames[start:end], ignore_index=True)

    return [
        combine_lots(boundaries[index], boundaries[index + 1])
        for index in range(len(target_counts))
    ]


def chronological_semi_supervised_split(
    df: pd.DataFrame,
    label_size: int,
    unlabel_size: int,
    valid_size: int | None = None,
    test_size: int | None = None,
    group_column: str | None = "LOT_ID",
):
    """Create LOT-safe train -> valid -> unlabeled -> test time blocks.

    ``label_size`` and ``unlabel_size`` are the labeled and unlabeled parts of
    the training pool. In the manuscript protocol they are 25% and 75% of that
    pool. Validation and test are excluded from this percentage calculation.
    When their sizes are omitted, each is assigned approximately 10% of the
    complete dataset (the training pool occupies the other 80%).
    """
    if label_size < 1:
        raise ValueError("label_size must be positive")
    if unlabel_size < 0:
        raise ValueError("unlabel_size cannot be negative")
    training_pool_size = label_size + unlabel_size
    if valid_size is None or test_size is None:
        inferred_total = int(round(training_pool_size / 0.8))
        inferred_holdout = max(1, int(round(inferred_total * 0.1)))
        valid_size = inferred_holdout if valid_size is None else valid_size
        test_size = (
            inferred_total - training_pool_size - int(valid_size)
            if test_size is None
            else test_size
        )
    if valid_size < 1 or test_size < 1:
        raise ValueError("valid_size and test_size must be positive")

    return tuple(
        chronological_grouped_block_split(
            df,
            [label_size, int(valid_size), unlabel_size, int(test_size)],
            group_column=group_column,
        )
    )
