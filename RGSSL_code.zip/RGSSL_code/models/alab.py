"""Paper-faithful Adaptive Learnable Attention Block (ALAB).

This module implements Eqs. (1)-(15) of the RGSSL manuscript:
feature tokenization, element-wise gated attention, the d -> 8d -> GEGLU
-> 4d -> d feed-forward network, and token-wise attention-based residual
aggregation over H0 and all preceding block transformations.
"""

from __future__ import annotations

import torch
import torch.nn.functional as F
from torch import nn


class GEGLU(nn.Module):
    def forward(self, x):
        values, gates = x.chunk(2, dim=-1)
        return values * F.gelu(gates)


class RMSNorm(nn.Module):
    def __init__(self, dim, eps=1e-8):
        super().__init__()
        self.scale = nn.Parameter(torch.ones(dim))
        self.eps = eps

    def forward(self, x):
        return x * torch.rsqrt(x.pow(2).mean(dim=-1, keepdim=True) + self.eps) * self.scale


class NumericalEmbedder(nn.Module):
    """Feature-specific numerical scale and bias from manuscript Eq. (2)."""

    def __init__(self, dim, num_continuous):
        super().__init__()
        self.weights = nn.Parameter(torch.randn(num_continuous, dim))
        self.biases = nn.Parameter(torch.randn(num_continuous, dim))

    def forward(self, x):
        return x.unsqueeze(-1) * self.weights + self.biases


class MultiHeadSelfAttention(nn.Module):
    def __init__(self, dim, heads, dim_head, dropout=0.0, use_qk_norm=False):
        super().__init__()
        self.heads = int(heads)
        self.dim_head = int(dim_head)
        self.inner_dim = self.heads * self.dim_head
        self.scale = self.dim_head ** -0.5
        self.use_qk_norm = bool(use_qk_norm)

        self.to_q = nn.Linear(dim, self.inner_dim, bias=False)
        self.to_kv = nn.Linear(dim, self.inner_dim * 2, bias=False)
        self.to_out = nn.Linear(self.inner_dim, dim, bias=False)
        self.dropout = nn.Dropout(dropout)
        if self.use_qk_norm:
            self.q_norm = nn.LayerNorm(self.dim_head)
            self.k_norm = nn.LayerNorm(self.dim_head)

    def forward(self, x):
        batch, tokens, _ = x.shape
        q = self.to_q(x).view(batch, tokens, self.heads, self.dim_head).transpose(1, 2)
        k, v = self.to_kv(x).chunk(2, dim=-1)
        k = k.view(batch, tokens, self.heads, self.dim_head).transpose(1, 2)
        v = v.view(batch, tokens, self.heads, self.dim_head).transpose(1, 2)
        if self.use_qk_norm:
            q = self.q_norm(q)
            k = self.k_norm(k)

        attention = torch.matmul(q * self.scale, k.transpose(-2, -1)).softmax(dim=-1)
        attention = self.dropout(attention)
        output = torch.matmul(attention, v)
        output = output.transpose(1, 2).contiguous().view(batch, tokens, self.inner_dim)
        return self.to_out(output), attention


class ALABLayer(nn.Module):
    """One ALAB with gated interactions and learnable residual aggregation."""

    def __init__(
        self,
        dim,
        heads,
        dim_head,
        attn_dropout=0.0,
        ff_dropout=0.0,
        gate_type="elementwise",
        use_qk_norm=False,
    ):
        super().__init__()
        if gate_type not in {"elementwise", "headwise", "none"}:
            raise ValueError(f"Unsupported gate_type: {gate_type}")
        if gate_type == "headwise" and dim % heads != 0:
            raise ValueError("dim must be divisible by heads for headwise gating")

        self.dim = int(dim)
        self.heads = int(heads)
        self.gate_type = gate_type
        self.input_norm = nn.LayerNorm(dim)
        self.attention = MultiHeadSelfAttention(
            dim,
            heads,
            dim_head,
            dropout=attn_dropout,
            use_qk_norm=use_qk_norm,
        )
        gate_dim = dim if gate_type == "elementwise" else heads
        self.gate = None if gate_type == "none" else nn.Linear(dim, gate_dim)
        self.ff_norm = nn.LayerNorm(dim)
        self.ff = nn.Sequential(
            nn.Linear(dim, dim * 8),
            GEGLU(),
            nn.Dropout(ff_dropout),
            nn.Linear(dim * 4, dim),
        )
        self.candidate_norm = RMSNorm(dim)
        self.residual_query = nn.Parameter(torch.randn(dim))

    def forward(self, hidden, original_embedding, previous_transformations):
        normalized = self.input_norm(hidden)
        attention_output, attention = self.attention(normalized)

        if self.gate is not None:
            gate = torch.sigmoid(self.gate(normalized))
            if self.gate_type == "headwise":
                gate = gate.repeat_interleave(self.dim // self.heads, dim=-1)
            attention_output = attention_output * gate

        intermediate = hidden + attention_output
        transformation = attention_output + self.ff(self.ff_norm(intermediate))
        candidates = [original_embedding, *previous_transformations, transformation]
        stacked = torch.stack(candidates, dim=0)
        scores = torch.einsum(
            "d,nbtd->nbt",
            self.residual_query,
            self.candidate_norm(stacked),
        )
        weights = scores.softmax(dim=0)
        output = torch.einsum("nbt,nbtd->btd", weights, stacked)
        return output, transformation, attention, weights


class ALABEncoder(nn.Module):
    def __init__(
        self,
        *,
        categories,
        num_continuous,
        dim,
        depth,
        heads,
        dim_head=16,
        num_special_tokens=2,
        attn_dropout=0.0,
        ff_dropout=0.0,
        gate_type="elementwise",
        use_qk_norm=False,
    ):
        super().__init__()
        categories = tuple(int(value) for value in categories)
        if any(value <= 0 for value in categories):
            raise ValueError("Every categorical cardinality must be positive")
        if len(categories) + int(num_continuous) <= 0:
            raise ValueError("At least one input feature is required")

        self.dim = int(dim)
        self.depth = int(depth)
        self.num_categories = len(categories)
        self.num_continuous = int(num_continuous)
        self.num_unique_categories = sum(categories)

        if self.num_unique_categories:
            offsets = F.pad(
                torch.tensor(categories, dtype=torch.long),
                (1, 0),
                value=int(num_special_tokens),
            ).cumsum(dim=-1)[:-1]
            self.register_buffer("categories_offset", offsets)
            self.categorical_embeds = nn.Embedding(
                self.num_unique_categories + int(num_special_tokens),
                dim,
            )
        if self.num_continuous:
            self.numerical_embedder = NumericalEmbedder(dim, self.num_continuous)

        self.cls_token = nn.Parameter(torch.randn(1, 1, dim))
        self.layers = nn.ModuleList(
            [
                ALABLayer(
                    dim,
                    heads,
                    dim_head,
                    attn_dropout=attn_dropout,
                    ff_dropout=ff_dropout,
                    gate_type=gate_type,
                    use_qk_norm=use_qk_norm,
                )
                for _ in range(depth)
            ]
        )

    def embed(self, x_categ, x_numer):
        if x_categ.shape[-1] != self.num_categories:
            raise ValueError(
                f"Expected {self.num_categories} categorical features, got {x_categ.shape[-1]}"
            )
        tokens = []
        if self.num_unique_categories:
            tokens.append(self.categorical_embeds(x_categ + self.categories_offset))
        if self.num_continuous:
            tokens.append(self.numerical_embedder(x_numer))
        embedded = torch.cat(tokens, dim=1)
        cls = self.cls_token.expand(embedded.shape[0], -1, -1)
        return torch.cat([cls, embedded], dim=1)

    def forward_tokens(self, tokens, noise_after_layer=None, noise_fn=None, return_attn=False):
        original_embedding = tokens
        hidden = tokens
        transformations = []
        attentions = []
        residual_weights = []
        for layer_index, layer in enumerate(self.layers, start=1):
            hidden, transformation, attention, weights = layer(
                hidden,
                original_embedding,
                transformations,
            )
            transformations.append(transformation)
            attentions.append(attention)
            residual_weights.append(weights)
            if noise_after_layer == layer_index and noise_fn is not None:
                hidden = noise_fn(hidden)

        if not return_attn:
            return hidden
        return hidden, attentions, residual_weights

    def forward(self, x_categ, x_numer, return_attn=False):
        return self.forward_tokens(self.embed(x_categ, x_numer), return_attn=return_attn)
