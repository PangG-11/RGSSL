from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import numpy as np
import torch
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from torch.utils.data import DataLoader

from dataset.dataload import dataset_kwargs_from_args, load_dataset
from models.semi_supervised import TabSSL
from project_paths import experiment_name


def test(args):
    cat_dims, _, con_idxs, _, valid_dataset, test_dataset, _ = load_dataset(
        args.data,
        **dataset_kwargs_from_args(args),
    )
    test_loader = DataLoader(
        test_dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=getattr(args, "num_workers", 0),
    )

    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    model = TabSSL(
        args=args,
        categories=cat_dims,
        num_continuous=len(con_idxs),
    ).to(device)

    training_mode = "supervised" if getattr(args, "supervised_only", False) else "semi_supervised"
    checkpoint_path = (
        PROJECT_ROOT
        / "save_model"
        / training_mode
        / experiment_name(args)
        / "best_model.pth"
    )
    checkpoint = torch.load(checkpoint_path, map_location=device)
    state_dict = checkpoint.get("model_state_dict", checkpoint)
    model.load_state_dict(state_dict)
    model.eval()

    all_preds = []
    all_labels = []
    with torch.no_grad():
        for x_cat, x_con, label in test_loader:
            pred = model(
                x_cat.to(device).long(),
                x_con.to(device).float(),
            )
            all_preds.append(pred.cpu().numpy().reshape(-1))
            all_labels.append(label.numpy().reshape(-1))

    predictions = np.concatenate(all_preds)
    labels = np.concatenate(all_labels)
    mse = mean_squared_error(labels, predictions)
    return {
        "MSE": mse,
        "MAE": mean_absolute_error(labels, predictions),
        "RMSE": np.sqrt(mse),
        "R2": r2_score(labels, predictions),
        "num_samples": len(labels),
    }
