# Data placement

Private foundry data are not included. Put each scenario CSV in this directory or
pass an absolute path with `--data_path`.

Required fields:

- one row per wafer;
- CP yield target, normally named `yield`, on the 0-100 percentage scale;
- a CP completion timestamp, preferably `CP_COMPLETION_TIME`;
- a LOT key, preferably `LOT_ID`;
- WAT feature columns;
- optional `WAFER_ID`, which is removed before modelling.

Paper subset targets:

| Scenario | Labeled | Validation | Unlabeled | Test |
|---|---:|---:|---:|---:|
| Data1 | 1040 | 520 | 3120 | 520 |
| Data2 | 1100 | 550 | 3300 | 550 |
| Data3 | 1150 | 575 | 3450 | 570 |
| Data4 | 1220 | 610 | 3660 | 610 |
| Data5 | 1000 | 600 | 3000 | 600 |

Example from the `RGSSL_code` directory:

```powershell
python main.py --data CSV --data_path data/Data1.csv --dataset_name Data1 `
  --target_col yield --time_column CP_COMPLETION_TIME --group_column LOT_ID `
  --label_size 1040 --valid_size 520 --unlabel_size 3120 --test_size 520
```

