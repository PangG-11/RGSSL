# RGSSL 论文独立运行代码

本目录可单独复制、压缩或上传，不依赖父目录，也不依赖外部
`tab-transformer-pytorch-main`。数据、缓存和模型输出路径均相对于本目录解析。

## 目录结构

```text
RGSSL_code/
├─ main.py                    # 训练/测试入口
├─ smoke_test.py              # 无私有数据的一键完整性测试
├─ project_paths.py           # 独立目录路径配置
├─ models/alab.py             # 论文公式 (1)-(15) 的 ALAB 实现
├─ models/                    # ALAB 与 TabSSL/RGSSL 模型
├─ dataset/                   # 数据加载与 Wafer 数据准备
├─ train/                     # 训练、测试与预训练实现
└─ requirements.txt           # 主要 Python 依赖
```

## 核心代码

- `models/alab.py`：逐项实现论文中的特征嵌入、element-wise gated attention、
  GEGLU FFN 和跨深度注意力残差聚合。
- `models/semi_supervised.py`：TabSSL/RGSSL 编码器、预测头及半监督模型封装。
- `train/train.py`：监督损失、共享模型弱/强视图、stop-gradient 伪目标、不确定性筛选和训练循环。
- `dataset/dataload.py`：数据读取、预处理、标签/无标签数据构造。
- `main.py`：统一命令行入口。

## 快速开始

在任意机器解压后进入本目录：

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python smoke_test.py
```

看到 `RGSSL standalone smoke test: PASS` 表示数据划分、ALAB、弱/强视图、损失和
反向传播均可运行。演示数据由代码确定性生成，不包含论文私有数据。

训练/测试入口：

```powershell
python main.py --mode train --data Demo --epochs 1
python main.py --mode train --data <dataset_name>
python main.py --mode test --data <dataset_name>
python dataset/prepare_varsize811_label_delayed.py --label_ratio 0.25
```

对任意论文格式CSV，可直接运行：

```powershell
python main.py --data CSV --data_path data/Data1.csv --dataset_name Data1 `
  --target_col yield --time_column CP_COMPLETION_TIME --group_column LOT_ID `
  --label_size 1040 --valid_size 520 --unlabel_size 3120 --test_size 520
```

Data1–Data5的准确子集数量和CSV字段要求见 `data/README.md`。

当前默认编码器为 6 层、隐藏维度 `d=256`。每层 FFN 与方法说明一致：线性层先将
`d` 扩展至 `8d`，GEGLU 将其压缩为 `4d`，最后再投影回 `d`。注意力使用8个头，
每头16维，拼接后的128维注意力结果投影回256维。门控默认使用论文式(5)的
`elementwise` 模式；`--block_size` 仅为兼容旧命令行保留，论文实现会在每层聚合
原始嵌入及所有先前层的变换表示。

RGSSL 的弱扰动在第1个完整 ALAB 后注入，扰动结果继续通过后续5层；强扰动在
第6个完整 ALAB 后、预测头前注入。K个弱视图和强视图来自同一个共享模型，弱视图
均值通过 stop-gradient 形成伪目标，不使用 EMA Teacher。

论文默认训练配置为 Adam、学习率 `1e-4`、权重衰减 `1e-3`、余弦退火和100轮；
每步使用64个有标签样本和64个无标签样本。`K=5`、`tau_u=0.3`、弱/强高斯噪声
标准差为0.01/0.05，一致性权重在前50轮线性增加到0.2。

## 时间顺序划分

- 原始表先按时间列升序稳定排序，再按过去到未来划分为：有标签训练集 → 验证集 →
  无标签训练集 → 测试集。标签比例仅在训练池中计算：默认训练池的25%为有标签、
  75%为无标签；验证集和测试集不进入25%标签预算。未显式指定数量时，训练池约占
  全部样本80%，验证集和测试集各约占10%。
- 划分默认以 `LOT_ID` 为完整分组单位：先按每个 LOT 第一次出现的时间确定 LOT
  顺序，再把边界移动到最接近目标样本数的完整 LOT 边界。同一 LOT 不会跨集合，
  因此各集合的实际 wafer 数可能与目标数略有差异。可用 `--group_column <列名>`
  指定其他分组列。
- 对没有独立 `LOT_ID`、但 `WAFER_ID` 形如 `HKU101_1` 的 SMIC 数据，读取器会自动
  将最后一个下划线前的部分提取为 `LOT_ID`，随后删除原 `WAFER_ID` 特征。
- 默认优先识别 `CP_COMPLETION_TIME`、`CP_COMPLETE_TIME`、`CP_END_TIME`，随后识别
  `START_TIME`、`LOAD_TIME`、`TEST_DAY`、`timestamp`、`datetime`、`date` 和
  `time`；也可用 `--time_column <列名>` 明确指定。
- 时间列仅用于排序，不进入模型特征，避免时间泄漏。
- `LOT_ID` 仅用于防泄漏划分，不进入模型特征。缺失值中位数、分类编码和数值标准化
  均只在有标签训练集上拟合，再原样应用到验证、无标签和测试数据。
- 私有半导体数据的良率保持0–100百分数尺度，MAE/RMSE对应百分点；不会再除以100。
- 若找不到 `LOT_ID`（或指定的分组列），代码会警告并退回逐行时间划分。
- 如果数据中没有时间列，代码会发出警告并保持源文件行顺序，不再执行随机划分。
- 旧的随机划分缓存不会被继续加载，需要使用修改后的准备脚本重新生成。

## 数据与输出

出于工业保密要求，本目录不包含五个私有晶圆数据集。它包含可直接运行的合成演示
数据生成器和通用CSV入口。运行后会在本目录内自动生成：

- `data_processed/`：处理后的训练、验证、无标签和测试数据；
- `save_model/`：检查点、最佳模型、训练历史和测试结果。

如需复现论文私有数据结果，请按 `data/README.md` 放置经授权的CSV；代码不会从父目录
读取数据，也不会把私有数据打包进上传文件。

