"""Paths anchored to the standalone RGSSL_code directory."""

from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parent
DATA_DIR = PROJECT_ROOT / "data"
PROCESSED_DIR = PROJECT_ROOT / "data_processed"
MODEL_DIR = PROJECT_ROOT / "save_model"


def project_path(path):
    """Resolve relative user paths against RGSSL_code, not the current shell."""
    value = Path(path)
    return value if value.is_absolute() else PROJECT_ROOT / value


def experiment_name(args):
    """Return a stable output name for built-in or custom CSV datasets."""
    data_name = str(getattr(args, "data", "dataset"))
    if data_name.lower() in {"csv", "custom_csv"}:
        return str(getattr(args, "dataset_name", "custom_csv"))
    return data_name

