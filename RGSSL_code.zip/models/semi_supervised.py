"""RGSSL model using the external Gated_TransRes encoder."""

from itertools import chain
import os
from pathlib import Path
import sys

import torch
import torch.nn as nn
import torch.nn.functional as F


GATED_TRANSRES_ROOT = Path(
    os.environ.get("GATED_TRANSRES_ROOT", r"D:\GP\tab-transformer-pytorch-main")
)
if str(GATED_TRANSRES_ROOT) not in sys.path:
    sys.path.insert(0, str(GATED_TRANSRES_ROOT))

try:
    from tab_transformer_pytorch.Gated_TransRes import GateTransformerWithAttnRes
except ImportError as exc:
    raise ImportError(
        "Unable to import GateTransformerWithAttnRes from "
        f"{GATED_TRANSRES_ROOT}. Set GATED_TRANSRES_ROOT to the directory that "
        "contains the tab_transformer_pytorch package."
    ) from exc


class Encoder(nn.Module):
    """Adapter that exposes Gated_TransRes as an RGSSL latent encoder."""

    def __init__(
        self,
        *,
        categories,
        num_continuous,
        dim,
        depth,
        heads,
        dim_head=16,
        dim_out=1,
        block_size=8,
        num_special_tokens=2,
        attn_dropout=0.0,
        ff_dropout=0.0,
        gate_type="headwise",
        use_qk_norm=False,
        weak_noise_std=0.01,
        strong_noise_std=0.05,
        noise_type="gaussian",
    ):
        super().__init__()
        if block_size < 2:
            raise ValueError("block_size must be at least 2 for Gated_TransRes")

        self.weak_noise_std = float(weak_noise_std)
        self.strong_noise_std = float(strong_noise_std)
        self.noise_type = noise_type
        self.depth = int(depth)
        self.weak_noise_after_layer = 1
        self.strong_noise_after_layer = self.depth

        # The external model's output head is set to `dim`, so its CLS output is
        # the latent representation consumed by the RGSSL prediction/pretrain heads.
        self.backbone = GateTransformerWithAttnRes(
            categories=tuple(categories),
            num_continuous=num_continuous,
            dim=dim,
            dim_out=dim,
            depth=depth,
            heads=heads,
            dim_head=dim_head,
            block_size=block_size,
            num_special_tokens=num_special_tokens,
            attn_dropout=attn_dropout,
            ff_dropout=ff_dropout,
            gate_type=gate_type,
            use_qk_norm=use_qk_norm,
        )

    def forward(self, x_categ, x_numer, return_attn=False):
        return self.backbone(x_categ, x_numer, return_attn=return_attn)

    def _add_noise(self, latent, noise_std):
        if noise_std <= 0 or self.noise_type == "none":
            return latent
        if self.noise_type == "gaussian":
            return latent + torch.randn_like(latent) * noise_std
        if self.noise_type == "uniform":
            return latent + (torch.rand_like(latent) * 2 - 1) * noise_std
        if self.noise_type == "bernoulli":
            drop_mask = torch.bernoulli(torch.full_like(latent, noise_std))
            return latent * (1 - drop_mask)
        raise ValueError(f"Unsupported noise_type: {self.noise_type}")

    def _embed_tokens(self, x_categ, x_numer):
        """Build categorical/numerical tokens and prepend the CLS token."""
        backbone = self.backbone
        if x_categ.shape[-1] != backbone.num_categories:
            raise ValueError(
                f"Expected {backbone.num_categories} categorical features, "
                f"got {x_categ.shape[-1]}"
            )

        tokens = []
        if backbone.num_unique_categories > 0:
            categorical = x_categ + backbone.categories_offset
            tokens.append(backbone.categorical_embeds(categorical))
        if backbone.num_continuous > 0:
            tokens.append(backbone.numerical_embedder(x_numer))

        embedded = torch.cat(tokens, dim=1)
        cls_tokens = backbone.cls_token.expand(embedded.shape[0], -1, -1)
        return torch.cat((cls_tokens, embedded), dim=1)

    def _forward_with_layer_noise(self, x_categ, x_numer, view):
        """Run Gated_TransRes and inject noise at the requested layer boundary."""
        if view not in {"weak", "strong"}:
            raise ValueError(f"Unsupported perturbation view: {view}")

        tokens = self._embed_tokens(x_categ, x_numer)
        transformer = self.backbone.transformer
        blocks = [tokens]
        partial_block = tokens.clone()
        layer_output = tokens

        for layer_index, layer in enumerate(transformer.layers, start=1):
            blocks, partial_block, layer_output = layer(
                blocks,
                partial_block,
                tokens if layer_index == 1 else layer_output,
            )

            # Weak perturbation is injected after the complete first layer, then
            # propagated through all remaining Gated_TransRes layers.
            if view == "weak" and layer_index == self.weak_noise_after_layer:
                partial_block = self._add_noise(
                    partial_block,
                    self.weak_noise_std,
                )

        encoded_tokens = transformer.norm(partial_block)

        # Strong perturbation is injected after the complete final layer and its
        # final normalization, immediately before CLS projection.
        if view == "strong":
            encoded_tokens = self._add_noise(
                encoded_tokens,
                self.strong_noise_std,
            )

        cls_latent = encoded_tokens[:, 0]
        return self.backbone.to_logits(cls_latent)

    def return_noised_attention(self, x_categ, x_numer, return_attn=False):
        weak = self._forward_with_layer_noise(x_categ, x_numer, view="weak")
        strong = self._forward_with_layer_noise(x_categ, x_numer, view="strong")
        return weak, strong

    def return_weak_attention(self, x_categ, x_numer):
        return self._forward_with_layer_noise(x_categ, x_numer, view="weak")

    def return_strong_attention(self, x_categ, x_numer):
        return self._forward_with_layer_noise(x_categ, x_numer, view="strong")


class Feature_estimator(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.feature_estimator = nn.Sequential(
            nn.LayerNorm(dim), nn.ReLU(), nn.Linear(dim, 1)
        )

    def forward(self, x):
        return self.feature_estimator(x)


class Mask_estimator(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.mask_estimator = nn.Sequential(
            nn.LayerNorm(dim), nn.ReLU(), nn.Linear(dim, dim)
        )

    def forward(self, x):
        return self.mask_estimator(x)


class TabSSL(nn.Module):
    def __init__(self, args, categories, num_continuous):
        super().__init__()
        self.dim = args.dim
        self.pretrain_out = len(categories) + num_continuous
        self.encoder = Encoder(
            categories=categories,
            num_continuous=num_continuous,
            dim=args.dim,
            dim_out=args.dim_out,
            depth=args.depth,
            heads=args.heads,
            dim_head=getattr(args, "dim_head", 16),
            block_size=getattr(args, "block_size", 8),
            num_special_tokens=getattr(args, "num_special_tokens", 2),
            attn_dropout=args.attn_dropout,
            ff_dropout=args.ff_dropout,
            gate_type=args.gate_type,
            use_qk_norm=args.use_qk_norm,
            weak_noise_std=getattr(args, "weak_noise_std", 0.01),
            strong_noise_std=getattr(args, "strong_noise_std", 0.05),
            noise_type=getattr(args, "noise_type", "gaussian"),
        )

        self.mask_estimator = nn.Sequential(
            nn.LayerNorm(self.dim),
            nn.ReLU(),
            nn.Linear(self.dim, self.pretrain_out),
        )
        self.feature_estimator = nn.Sequential(
            nn.LayerNorm(self.dim),
            nn.ReLU(),
            nn.Linear(self.dim, self.pretrain_out),
        )
        self.to_out = nn.Sequential(
            nn.LayerNorm(self.dim),
            nn.ReLU(),
            nn.Linear(self.dim, args.dim_out),
        )

    def forward(self, x_cat, x_con):
        latent = self.encoder(x_cat, x_con)
        return self.to_out(latent)

    def predict(self, x_cat, x_con):
        return self.forward(x_cat, x_con)

    def get_nosied_output(self, x_cat, x_con):
        x_weak, x_strong = self.encoder.return_noised_attention(x_cat, x_con)
        return self.to_out(x_weak), self.to_out(x_strong)

    def get_weak_output(self, x_cat, x_con):
        return self.to_out(self.encoder.return_weak_attention(x_cat, x_con))

    def get_strong_output(self, x_cat, x_con):
        return self.to_out(self.encoder.return_strong_attention(x_cat, x_con))

    def test_loss(self, x_categ, x_cont, target):
        output = self.predict(x_categ, x_cont)
        return F.binary_cross_entropy(output, target, reduction="mean")

    def pretrain(self, x_cat, x_con):
        latent = self.encoder(x_cat, x_con)
        return self.feature_estimator(latent), self.mask_estimator(latent)

    def pretrain_params(self):
        return chain(
            self.mask_estimator.parameters(),
            self.feature_estimator.parameters(),
            self.encoder.parameters(),
        )

    def train_params(self):
        return chain(self.encoder.parameters(), self.to_out.parameters())
