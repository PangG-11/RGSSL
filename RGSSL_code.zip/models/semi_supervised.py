from itertools import chain
import numpy as np
import torch
import torch.nn as nn
from models.Gated_transformer import *
import torch.nn.functional as F

class Encoder(nn.Module):
    def __init__(self,
                 *,
                 categories,
                 num_continuous,
                 dim,
                 depth,
                 heads,
                 dim_head=16,
                 dim_out=1,
                 num_special_tokens=2,
                 attn_dropout=0.,
                 ff_dropout=0.,
                 gate_type='headwise',
                 use_qk_norm=False,
                 weak_noise_std=0.01,
                 strong_noise_std=0.05,
                 noise_type='gaussian',
    ):
        super().__init__()
        assert all(map(lambda n: n > 0, categories)), 'number of each category must be positive'
        assert len(categories) + num_continuous > 0, 'input shape must not be null'

        # categories related calculations

        self.num_categories = len(categories)
        self.num_unique_categories = sum(categories)

        # create category embeddings table

        self.num_special_tokens = num_special_tokens
        total_tokens = self.num_unique_categories + num_special_tokens

        # for automatically offsetting unique category ids to the correct position in the categories embedding table

        if self.num_unique_categories > 0:
            categories_offset = F.pad(torch.tensor(list(categories)), (1, 0), value=num_special_tokens)
            categories_offset = categories_offset.cumsum(dim=-1)[:-1]
            self.register_buffer('categories_offset', categories_offset)

            # categorical embedding

            self.categorical_embeds = nn.Embedding(total_tokens, dim)

        # continuous

        self.num_continuous = num_continuous

        if self.num_continuous > 0:
            self.numerical_embedder = NumericalEmbedder(dim, self.num_continuous)

        # cls token

        self.cls_token = nn.Parameter(torch.randn(1, 1, dim))

        # transformer

        self.transformer = GatedTransformer(
            dim=dim,
            depth=depth,
            heads=heads,
            dim_head=dim_head,
            attn_dropout=attn_dropout,
            ff_dropout=ff_dropout,
            gate_type=gate_type,
            use_qk_norm=use_qk_norm,
            weak_noise_std=weak_noise_std,
            strong_noise_std=strong_noise_std,
            noise_type=noise_type,
        )


    def forward(self, x_categ, x_numer, return_attn=False):
        assert x_categ.shape[
                   -1] == self.num_categories, f'you must pass in {self.num_categories} values for your categories input'

        xs = []
        if self.num_unique_categories > 0:
            x_categ = x_categ + self.categories_offset

            x_categ = self.categorical_embeds(x_categ)

            xs.append(x_categ)

        # add numerically embedded tokens
        if self.num_continuous > 0:
            x_numer = self.numerical_embedder(x_numer)

            xs.append(x_numer)

        # concat categorical and numerical

        x = torch.cat(xs, dim=1)

        # append cls tokens
        b = x.shape[0]
        cls_tokens = repeat(self.cls_token, '1 1 d -> b 1 d', b=b)
        x = torch.cat((cls_tokens, x), dim=1)
        # attend

        x, attns = self.transformer(x, return_attn=True)

        # get cls token
        x = x[:, 0]

        return x

    def return_noised_attention(self, x_categ, x_numer, return_attn=False):
        assert x_categ.shape[
                   -1] == self.num_categories, f'you must pass in {self.num_categories} values for your categories input'

        xs = []
        if self.num_unique_categories > 0:
            x_categ = x_categ + self.categories_offset

            x_categ = self.categorical_embeds(x_categ)

            xs.append(x_categ)

        # add numerically embedded tokens
        if self.num_continuous > 0:
            x_numer = self.numerical_embedder(x_numer)

            xs.append(x_numer)

        # concat categorical and numerical

        x = torch.cat(xs, dim=1)

        # append cls tokens
        b = x.shape[0]
        cls_tokens = repeat(self.cls_token, '1 1 d -> b 1 d', b=b)
        x = torch.cat((cls_tokens, x), dim=1)

        # attend
        x_weak = self.transformer.add_weak_noise(x)
        x_strong = self.transformer.add_strong_noise(x)
        #get cls token
        x_weak = x_weak[:, 0]
        x_strong = x_strong[:, 0]
        return x_weak, x_strong

    def return_weak_attention(self, x_categ, x_numer):
        assert x_categ.shape[
                   -1] == self.num_categories, f'you must pass in {self.num_categories} values for your categories input'

        xs = []
        if self.num_unique_categories > 0:
            x_categ = x_categ + self.categories_offset
            x_categ = self.categorical_embeds(x_categ)
            xs.append(x_categ)

        if self.num_continuous > 0:
            x_numer = self.numerical_embedder(x_numer)
            xs.append(x_numer)

        x = torch.cat(xs, dim=1)
        b = x.shape[0]
        cls_tokens = repeat(self.cls_token, '1 1 d -> b 1 d', b=b)
        x = torch.cat((cls_tokens, x), dim=1)
        x_weak = self.transformer.add_weak_noise(x)
        return x_weak[:, 0]

    def return_strong_attention(self, x_categ, x_numer):
        assert x_categ.shape[
                   -1] == self.num_categories, f'you must pass in {self.num_categories} values for your categories input'

        xs = []
        if self.num_unique_categories > 0:
            x_categ = x_categ + self.categories_offset
            x_categ = self.categorical_embeds(x_categ)
            xs.append(x_categ)

        if self.num_continuous > 0:
            x_numer = self.numerical_embedder(x_numer)
            xs.append(x_numer)

        x = torch.cat(xs, dim=1)
        b = x.shape[0]
        cls_tokens = repeat(self.cls_token, '1 1 d -> b 1 d', b=b)
        x = torch.cat((cls_tokens, x), dim=1)
        x_strong = self.transformer.add_strong_noise(x)
        return x_strong[:, 0]

class Feature_estimator(nn.Module):
    def __init__(self,dim):
        super(Feature_estimator,self).__init__()
        self.feature_estimator = nn.Sequential(
            nn.LayerNorm(dim),
            nn.ReLU(),
            nn.Linear(dim, 1)
        )
    def forward(self,x):
        x = self.feature_estimator(x)
        return x


class Mask_estimator(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.mask_estimator = nn.Sequential(
            nn.LayerNorm(dim),
            nn.ReLU(),
            nn.Linear(dim, dim)
        )

    def forward(self, x):
        x = self.mask_estimator(x)
        return x


class TabSSL(nn.Module):
    def __init__(self,
                 args,
                 categories,
                 num_continuous,
                 ):
        super(TabSSL,self).__init__()
        self.dim = args.dim

        self.pretrain_out = len(categories)+num_continuous
        self.encoder = Encoder(
            categories=categories,
            num_continuous=num_continuous,
            dim=args.dim,
            dim_out=args.dim_out,
            depth=args.depth,
            heads=args.heads,
            attn_dropout=args.attn_dropout,
            ff_dropout=args.ff_dropout,
            gate_type=args.gate_type,
            use_qk_norm=args.use_qk_norm,
            weak_noise_std=getattr(args, 'weak_noise_std', 0.01),
            strong_noise_std=getattr(args, 'strong_noise_std', 0.05),
            noise_type=getattr(args, 'noise_type', 'gaussian'),)

        self.mask_estimator = nn.Sequential(
            nn.LayerNorm(self.dim),
            nn.ReLU(),
            nn.Linear(self.dim, len(categories) + num_continuous)
        )

        self.feature_estimator = nn.Sequential(
            nn.LayerNorm(self.dim),
            nn.ReLU(),
            nn.Linear(self.dim, len(categories) + num_continuous)
        )
        self.to_out = nn.Sequential(
            nn.LayerNorm(self.dim),
            nn.ReLU(),
            nn.Linear(self.dim, args.dim_out)
        )

    def forward(self,x_cat, x_con):
        latent= self.encoder(x_cat, x_con)
        pred = self.to_out(latent)
        return pred

    def get_nosied_output(self,x_cat,x_con):
        x_weak,x_strong = self.encoder.return_noised_attention(x_cat, x_con)
        y_w = self.to_out(x_weak)
        y_s = self.to_out(x_strong)
        return y_w,y_s

    def get_weak_output(self, x_cat, x_con):
        x_weak = self.encoder.return_weak_attention(x_cat, x_con)
        return self.to_out(x_weak)

    def get_strong_output(self, x_cat, x_con):
        x_strong = self.encoder.return_strong_attention(x_cat, x_con)
        return self.to_out(x_strong)

    def test_loss(self,x_categ, x_cont,target):
        output = self.predict(x_categ,x_cont)
        loss = F.binary_cross_entropy(output, target, reduction='mean')
        return loss

    def pretrain(self,x_cat,x_con):

        latent = self.encoder(x_cat, x_con)
        feature_pred = self.feature_estimator(latent)
        mask_pred = self.mask_estimator(latent)
        return feature_pred,mask_pred


    def pretrain_params(self):
        return chain(self.mask_estimator.parameters(),self.feature_estimator.parameters(), self.encoder.parameters())

    def train_params(self):
        return chain(self.encoder.parameters() ,self.to_out.parameters())











