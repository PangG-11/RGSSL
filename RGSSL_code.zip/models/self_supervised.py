from itertools import chain
import numpy as np
import torch
import torch.nn as nn
from models.Gated_transformer import *
import torch.nn.functional as F


class Encoder(nn.Module):
    def __init__(self,
                 *,
                 args,
                 categories,
                 num_continuous,
                 dim,
                 depth,
                 heads,
                 dim_out=1,
                 attn_dropout=0.,
                 ff_dropout=0.,
                 gate_type='headwise',  # 或 'elementwise'
                 use_qk_norm=False,
    ):
        super().__init__()


        self.Gate_transformer =  GateTransformer(
            categories=categories,  # 每个分类特征的类别数
            num_continuous=num_continuous,  # 连续特征的数量
            dim=dim,  # 特征维度
            dim_out=dim_out,  # 输出维度（回归任务）
            depth=depth,  # Transformer深度
            heads=heads,  # 注意力头数
            attn_dropout=attn_dropout,  # 注意力dropout
            ff_dropout=ff_dropout,  # 前馈网络dropout
            gate_type=gate_type,  # 或 'elementwise'
            use_qk_norm=use_qk_norm,
        )



    def forward(self, x_categ_ul,x_cont_ul):
        latent = self.Gate_transformer(x_categ_ul,x_cont_ul)
        return latent




class self_supervised(nn.Module):
    def __init__(self, encoder,classfier):
        super().__init__()
        self.encoder = encoder
        self.classfier = classfier

    def forward(self, x_lab,target_lab):
        x_lab_hat = self.encoder(x_lab)
        target_l = target_lab.float()
        output_l = F.softmax(self.classfier(x_lab_hat))
        loss_sup = F.binary_cross_entropy(output_l, target_l)
        return loss_sup, output_l

    def get_other_params(self):
        return chain(self.encoder.parameters(), self.classfier.parameters())







