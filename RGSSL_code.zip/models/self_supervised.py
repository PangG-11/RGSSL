from itertools import chain
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from models.semi_supervised import Encoder as GatedTranResEncoder


class Encoder(nn.Module):
    def __init__(self,
                 *,
                 args,
                 categories,
                 num_continuous,
                 dim,
                 depth,
                 heads,
                 dim_out=1,
                 attn_dropout=0.,
                 ff_dropout=0.,
                 gate_type='headwise',
                 use_qk_norm=False,
    ):
        super().__init__()


        self.Gate_transformer = GatedTranResEncoder(
            categories=categories,  # 每个分类特征的类别数
            num_continuous=num_continuous,  # 连续特征的数量
            dim=dim,  # 特征维度
            dim_out=dim,  # 编码器输出维度
            depth=depth,  # Transformer深度
            heads=heads,  # 注意力头数
            dim_head=getattr(args, 'dim_head', 16),
            block_size=getattr(args, 'block_size', 8),
            attn_dropout=attn_dropout,  # 注意力dropout
            ff_dropout=ff_dropout,  # 前馈网络dropout
            gate_type=gate_type,  # 或 'elementwise'
            use_qk_norm=use_qk_norm,
            weak_noise_std=getattr(args, 'weak_noise_std', 0.01),
            strong_noise_std=getattr(args, 'strong_noise_std', 0.05),
            noise_type=getattr(args, 'noise_type', 'gaussian'),
        )



    def forward(self, x_categ_ul,x_cont_ul):
        latent = self.Gate_transformer(x_categ_ul,x_cont_ul)
        return latent




class self_supervised(nn.Module):
    def __init__(self, encoder,classfier):
        super().__init__()
        self.encoder = encoder
        self.classfier = classfier

    def forward(self, x_lab,target_lab):
        x_lab_hat = self.encoder(x_lab)
        target_l = target_lab.float()
        output_l = F.softmax(self.classfier(x_lab_hat))
        loss_sup = F.binary_cross_entropy(output_l, target_l)
        return loss_sup, output_l

    def get_other_params(self):
        return chain(self.encoder.parameters(), self.classfier.parameters())







