import torch
import torch.nn.functional as F
from torch import nn, einsum

from einops import rearrange, repeat


# feedforward and attention

class GEGLU(nn.Module):
    def forward(self, x):
        x, gates = x.chunk(2, dim=-1)
        return x * F.gelu(gates)


def FeedForward(dim, mult=4, dropout=0.):
    return nn.Sequential(
        nn.LayerNorm(dim),
        nn.Linear(dim, dim * mult * 2),
        GEGLU(),
        nn.Dropout(dropout),
        nn.Linear(dim * mult, dim)
    )


class GatedAttention(nn.Module):
    def __init__(
            self,
            dim,
            heads=8,
            dim_head=64,
            dropout=0.,
            gate_type='headwise',  # 'headwise', 'elementwise', 或 'none'
            use_qk_norm=False,
    ):
        super().__init__()
        inner_dim = dim_head * heads
        self.heads = heads
        self.dim_head = dim_head
        self.inner_dim = inner_dim
        self.scale = dim_head ** -0.5
        self.gate_type = gate_type
        self.use_qk_norm = use_qk_norm

        self.norm = nn.LayerNorm(dim)

        # 根据门控类型调整查询投影
        if gate_type == 'headwise':
            self.to_q = nn.Linear(dim, inner_dim + heads, bias=False)
        elif gate_type == 'elementwise':
            self.to_q = nn.Linear(dim, inner_dim * 2, bias=False)
        else:  # 'none'
            self.to_q = nn.Linear(dim, inner_dim, bias=False)

        self.to_kv = nn.Linear(dim, inner_dim * 2, bias=False)
        self.to_out = nn.Linear(inner_dim, dim, bias=False)
        self.dropout = nn.Dropout(dropout)

        if use_qk_norm:
            self.q_norm = nn.LayerNorm(dim_head)
            self.k_norm = nn.LayerNorm(dim_head)

    def forward(self, x):
        h = self.heads
        d = self.dim_head
        inner_dim = self.inner_dim
        x = self.norm(x)

        # 处理查询
        q = self.to_q(x)

        # 分离门控参数
        gate_score = None
        if self.gate_type == 'headwise':
            # 正确计算分割尺寸
            q, gate_score = q.split([inner_dim, h], dim=-1)
            # 重塑为 [batch, seq_len, heads, 1]
            gate_score = gate_score.view(x.shape[0], x.shape[1], h, 1)
        elif self.gate_type == 'elementwise':
            q, gate_score = q.chunk(2, dim=-1)
            # 重塑为 [batch, seq_len, heads, dim_head]
            gate_score = gate_score.view(x.shape[0], x.shape[1], h, d)

        # 处理键值
        k, v = self.to_kv(x).chunk(2, dim=-1)

        # 重塑查询、键、值
        q = rearrange(q, 'b n (h d) -> b h n d', h=h)
        k = rearrange(k, 'b n (h d) -> b h n d', h=h)
        v = rearrange(v, 'b n (h d) -> b h n d', h=h)

        # QK归一化
        if self.use_qk_norm:
            q = self.q_norm(q)
            k = self.k_norm(k)

        q = q * self.scale

        # 注意力计算
        sim = einsum('b h i d, b h j d -> b h i j', q, k)
        attn = sim.softmax(dim=-1)
        attn = self.dropout(attn)

        out = einsum('b h i j, b h j d -> b h i d', attn, v)

        # 应用门控
        if gate_score is not None:
            # 调整gate_score维度以匹配out的维度 [batch, heads, seq_len, ...]
            gate_score = gate_score.permute(0, 2, 1, 3)  # [batch, heads, seq_len, ...]
            out = out * torch.sigmoid(gate_score)

        out = rearrange(out, 'b h n d -> b n (h d)', h=h)
        out = self.to_out(out)

        return out, attn


class GatedTransformer(nn.Module):
    def __init__(
            self,
            dim,
            depth,
            heads,
            dim_head,
            attn_dropout,
            ff_dropout,
            gate_type='none',  # 新增参数
            use_qk_norm=False,  # 新增参数
            weak_noise_std=0.05,  # 第一层噪声强度（弱噪声）
            strong_noise_std=0.1,  # 第四层噪声强度（强噪声）
            noise_type='gaussian',  # 噪声类型
    ):
        super().__init__()
        self.layers = nn.ModuleList([])
        self.weak_noise_std = weak_noise_std
        self.strong_noise_std = strong_noise_std
        self.noise_type = noise_type
        self.depth = depth
        for _ in range(depth):
            self.layers.append(nn.ModuleList([
                GatedAttention(
                    dim,
                    heads=heads,
                    dim_head=dim_head,
                    dropout=attn_dropout,
                    gate_type=gate_type,
                    use_qk_norm=use_qk_norm,
                ),
                FeedForward(dim, dropout=ff_dropout),
            ]))

    def forward(self, x, return_attn=False):
        post_softmax_attns = []

        for attn, ff in self.layers:
            attn_out, post_softmax_attn = attn(x)
            post_softmax_attns.append(post_softmax_attn)

            x = attn_out + x
            x = ff(x) + x

        if not return_attn:
            return x

        return x, torch.stack(post_softmax_attns)

    def add_weak_noise(self, x, return_attn=False):
        """仅在第一层添加噪声后的输出"""
        post_softmax_attns = []

        for layer_idx, (attn, ff) in enumerate(self.layers, start=1):
            attn_out, post_softmax_attn = attn(x)
            post_softmax_attns.append(post_softmax_attn)

            # 只在第一层添加弱噪声
            if layer_idx == 1 and self.weak_noise_std > 0:
                attn_out = self._add_noise_to_tensor(attn_out, self.weak_noise_std)

            x = attn_out + x
            x = ff(x) + x

        if not return_attn:
            return x

        return x, torch.stack(post_softmax_attns)
    def add_strong_noise(self, x, return_attn=False):
        """仅在最后一层添加噪声后的输出"""
        post_softmax_attns = []

        for layer_idx, (attn, ff) in enumerate(self.layers, start=1):
            attn_out, post_softmax_attn = attn(x)
            post_softmax_attns.append(post_softmax_attn)

            x = attn_out + x
            x = ff(x) + x

            # 只在最后一层添加强噪声（在残差连接之后）
            if layer_idx == self.depth and self.strong_noise_std > 0:
                x = self._add_noise_to_tensor(x, self.strong_noise_std)

        if not return_attn:
            return x

        return x, torch.stack(post_softmax_attns)

    def _add_noise_to_tensor(self, tensor, noise_std):
        """向张量添加噪声"""
        if self.noise_type == 'gaussian':
            noise = torch.randn_like(tensor) * noise_std
        elif self.noise_type == 'uniform':
            noise = (torch.rand_like(tensor) * 2 - 1) * noise_std
        elif self.noise_type == 'bernoulli':
            mask = torch.bernoulli(torch.ones_like(tensor) * noise_std)
            noise = -tensor * mask
        else:
            noise = torch.zeros_like(tensor)

        return tensor + noise

# numerical embedder

class NumericalEmbedder(nn.Module):
    def __init__(self, dim, num_numerical_types):
        super().__init__()
        self.weights = nn.Parameter(torch.randn(num_numerical_types, dim))
        self.biases = nn.Parameter(torch.randn(num_numerical_types, dim))

    def forward(self, x):
        x = rearrange(x, 'b n -> b n 1')
        return x * self.weights + self.biases


# main class

class GateTransformer(nn.Module):
    def __init__(
            self,
            *,
            categories,
            num_continuous,
            dim,
            depth,
            heads,
            dim_head=16,
            dim_out=1,
            num_special_tokens=2,
            attn_dropout=0.,
            ff_dropout=0.,
            gate_type='headwise',  # 或 'elementwise'
            use_qk_norm=False,
    ):
        super().__init__()
        assert all(map(lambda n: n > 0, categories)), 'number of each category must be positive'
        assert len(categories) + num_continuous > 0, 'input shape must not be null'

        # categories related calculations

        self.num_categories = len(categories)
        self.num_unique_categories = sum(categories)

        # create category embeddings table

        self.num_special_tokens = num_special_tokens
        total_tokens = self.num_unique_categories + num_special_tokens

        # for automatically offsetting unique category ids to the correct position in the categories embedding table

        if self.num_unique_categories > 0:
            categories_offset = F.pad(torch.tensor(list(categories)), (1, 0), value=num_special_tokens)
            categories_offset = categories_offset.cumsum(dim=-1)[:-1]
            self.register_buffer('categories_offset', categories_offset)

            # categorical embedding

            self.categorical_embeds = nn.Embedding(total_tokens, dim)

        # continuous

        self.num_continuous = num_continuous

        if self.num_continuous > 0:
            self.numerical_embedder = NumericalEmbedder(dim, self.num_continuous)

        # cls token

        self.cls_token = nn.Parameter(torch.randn(1, 1, dim))

        # transformer

        self.transformer = GatedTransformer(
            dim=dim,
            depth=depth,
            heads=heads,
            dim_head=dim_head,
            attn_dropout=attn_dropout,
            ff_dropout=ff_dropout,
            gate_type=gate_type,
            use_qk_norm=use_qk_norm,
        )

        # to logits

        self.to_logits = nn.Sequential(
            nn.LayerNorm(dim),
            nn.ReLU(),
            nn.Linear(dim, dim_out)
        )

    def forward(self, x_categ, x_numer, return_attn=False):
        assert x_categ.shape[
                   -1] == self.num_categories, f'you must pass in {self.num_categories} values for your categories input'

        xs = []
        if self.num_unique_categories > 0:
            x_categ = x_categ + self.categories_offset

            x_categ = self.categorical_embeds(x_categ)

            xs.append(x_categ)

        # add numerically embedded tokens
        if self.num_continuous > 0:
            x_numer = self.numerical_embedder(x_numer)

            xs.append(x_numer)

        # concat categorical and numerical

        x = torch.cat(xs, dim=1)

        # append cls tokens
        b = x.shape[0]
        cls_tokens = repeat(self.cls_token, '1 1 d -> b 1 d', b=b)
        x = torch.cat((cls_tokens, x), dim=1)

        # attend

        x, attns = self.transformer(x, return_attn=True)

        # get cls token

        x = x[:, 0]

        # out in the paper is linear(relu(ln(cls)))

        logits = self.to_logits(x)

        if not return_attn:
            return logits

        return x