# RGSSL 代码归档

本目录从原项目中复制并整理 RGSSL 的模型实现、训练入口和数据处理代码。原文件未移动、未删除，现有项目运行不受影响。

## 目录结构

```text
RGSSL_code/
├─ main.py                    # 训练/测试入口
├─ models/                    # ALAB/Gated Transformer 与 TabSSL/RGSSL 模型
├─ dataset/                   # 数据加载与 Wafer 数据准备
├─ train/                     # 训练、测试与预训练实现
└─ requirements.txt           # 主要 Python 依赖
```

## 核心代码

- `models/Gated_transformer.py`：Gated Attention、Gated Transformer 和数值特征嵌入。
- `models/semi_supervised.py`：TabSSL/RGSSL 编码器、预测头及半监督模型封装。
- `train/train.py`：监督损失、一致性损失、EMA Teacher、不确定性筛选、弱/强特征扰动和训练循环。
- `dataset/dataload.py`：数据读取、预处理、标签/无标签数据构造。
- `main.py`：统一命令行入口。

## 训练入口

在本目录中执行：

```powershell
python main.py --mode train --data <dataset_name>
python main.py --mode test --data <dataset_name>
```

## 数据与输出

本归档只包含代码与方法说明，不包含以下内容：

- `data/`、`data_processed/` 中的数据集；
- `save_model/` 中的模型权重；
- `runs/`、`outputs/` 中的运行结果；
- 绘图与结果分析代码；
- 已生成的 PNG、PDF、SVG 等图像文件。

运行训练前，请将所需数据按原项目结构放入本目录对应位置，或在脚本参数中指定实际数据位置。

