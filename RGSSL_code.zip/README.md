# RGSSL 代码归档

本目录从原项目中复制并整理 RGSSL 的模型实现、训练入口和数据处理代码。原文件未移动、未删除，现有项目运行不受影响。

## 目录结构

```text
RGSSL_code/
├─ main.py                    # 训练/测试入口
├─ models/                    # ALAB/Gated Transformer 与 TabSSL/RGSSL 模型
├─ dataset/                   # 数据加载与 Wafer 数据准备
├─ train/                     # 训练、测试与预训练实现
└─ requirements.txt           # 主要 Python 依赖
```

## 核心代码

- `models/semi_supervised.py`：通过适配层使用
  `D:\GP\tab-transformer-pytorch-main\tab_transformer_pytorch\Gated_TransRes.py`
  中的 `GateTransformerWithAttnRes` 作为编码器。
- `models/semi_supervised.py`：TabSSL/RGSSL 编码器、预测头及半监督模型封装。
- `train/train.py`：监督损失、一致性损失、EMA Teacher、不确定性筛选、弱/强特征扰动和训练循环。
- `dataset/dataload.py`：数据读取、预处理、标签/无标签数据构造。
- `main.py`：统一命令行入口。

## 训练入口

在本目录中执行：

```powershell
python main.py --mode train --data <dataset_name>
python main.py --mode test --data <dataset_name>
```

编码器默认从 `D:\GP\tab-transformer-pytorch-main` 导入。若代码移动到其他机器，设置
环境变量 `GATED_TRANSRES_ROOT` 指向包含 `tab_transformer_pytorch` 包的目录。可用
`--block_size` 调整 Gated_TransRes 的 attention-residual block 大小。

当前默认编码器为 6 层、隐藏维度 `d=256`。每层 FFN 与方法说明一致：线性层先将
`d` 扩展至 `8d`，GEGLU 将其压缩为 `4d`，最后再投影回 `d`。该结构由外部
`Gated_TransRes.py` 的 `FeedForward(dim, mult=4)` 实现。
注意力门控入口默认使用 `headwise`；如需对照实验，可显式传入
`--gate_type elementwise` 或 `--gate_type none`。

RGSSL 的弱扰动在第 1 个完整 Gated_TransRes 层结束后注入，扰动结果继续通过后续
5 层；强扰动在第 6 个完整层及最终归一化结束后注入，再进入 CLS 输出投影。普通
监督前向不注入扰动。

## 时间顺序划分

- 原始表先按时间列升序稳定排序，再按过去到未来划分为：有标签训练集 → 验证集 →
  无标签训练集 → 测试集。有标签总量仍按约 70% / 10% / 20% 分配给训练、验证和
  测试，无标签样本整体插入验证集和测试集之间，确保测试集始终是最新时间段。
- 默认依次识别 `START_TIME`、`LOAD_TIME`、`TEST_DAY`、`timestamp`、`datetime`、
  `date` 和 `time`；也可用 `--time_column <列名>` 明确指定。
- 时间列仅用于排序，不进入模型特征，避免时间泄漏。
- 如果数据中没有时间列，代码会发出警告并保持源文件行顺序，不再执行随机划分。
- 旧的随机划分缓存不会被继续加载，需要使用修改后的准备脚本重新生成。

## 数据与输出

本归档只包含代码与方法说明，不包含以下内容：

- `data/`、`data_processed/` 中的数据集；
- `save_model/` 中的模型权重；
- `runs/`、`outputs/` 中的运行结果；
- 绘图与结果分析代码；
- 已生成的 PNG、PDF、SVG 等图像文件。

运行训练前，请将所需数据按原项目结构放入本目录对应位置，或在脚本参数中指定实际数据位置。

