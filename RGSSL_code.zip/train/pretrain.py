from pathlib import Path as _Path
import sys as _sys
_PROJECT_ROOT = _Path(__file__).resolve().parents[1]
if str(_PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_PROJECT_ROOT))

import argparse
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset
from tqdm import tqdm
import warnings
from models.semi_supervised import TabSSL
import os

warnings.filterwarnings('ignore')
os.environ['CUDA_LAUNCH_BLOCKING'] = '1'


def mask_generator(x_unlab, p_m=0.1):
    """Generate mask vector.

    Args:
      - p_m: corruption probability
      - x: feature matrix

    Returns:
      - mask: binary mask matrix
    """
    mask = np.random.binomial(1, p_m, x_unlab.shape)
    return mask


def pretext_generator(m, x_unlab):
    """Generate corrupted samples.

    Args:
      m: mask matrix
      x: feature matrix

    Returns:
      m_new: final mask matrix after corruption
      x_tilde: corrupted feature matrix
    """
    no, dim = x_unlab.shape
    # Randomly (and column-wise) shuffle data
    x_bar = np.zeros([no, dim])
    for i in range(dim):
        idx = np.random.permutation(no)
        x_bar[:, i] = x_unlab[idx, i]

    # Corrupt samples
    x_tilde = x_unlab * (1 - m) + x_bar * m
    # Define new mask matrix
    m_new = 1 * (x_unlab != x_tilde)
    x_tilde = torch.tensor(x_tilde)
    m_new = torch.tensor(m_new, dtype=torch.float)
    return m_new, x_tilde


class PreTrainWrapper(nn.Module):
    """预训练包装器，适配新的TabSSL模型"""

    def __init__(self, args, categories, num_continuous):
        super(PreTrainWrapper, self).__init__()

        # 创建TabSSL模型
        self.tabssl = TabSSL(
            args=args,
            categories=categories,
            num_continuous=num_continuous
        )

        # 预训练特定的参数
        self.alpha = args.alpha if hasattr(args, 'alpha') else 0.01
        self.p_m = args.p_m if hasattr(args, 'p_m') else 0.1

        # 预训练头（使用TabSSL中已有的estimator）
        self.value_estimator = self.tabssl.feature_estimator
        self.position_estimator = self.tabssl.mask_estimator

    def forward(self, x_cat, x_con, y_pos, y_val):
        """前向传播，返回预训练损失"""
        # 预测掩码和特征值
        feature_output,mask_output = self.tabssl.pretrain(x_cat, x_con)
        # 计算损失
        loss1 = F.binary_cross_entropy_with_logits(mask_output, y_pos)
        loss2 = F.mse_loss(feature_output, y_val)
        loss = loss1 + self.alpha * loss2

        return loss, mask_output, feature_output

    def save_weights(self, save_dir='save_model/pretrain'):
        """保存编码器权重"""
        os.makedirs(save_dir, exist_ok=True)
        torch.save(self.tabssl.state_dict(), f'{save_dir}/tabssl_pretrain.pth')

    def load_model(self, load_path):
        """加载编码器权重"""
        if os.path.exists(load_path):
            self.tabssl.load_state_dict(torch.load(load_path))
            print(f"加载预训练编码器权重: {load_path}")
            return True
        return False

    def pretrain_params(self):
        return self.tabssl.pretrain_params()


class MaskedDataset(Dataset):
    """掩码数据集"""

    def __init__(self, x_categ_tilde, x_cont_tilde, m_label, x):
        self.x_categ_tilde = x_categ_tilde
        self.x_cont_tilde = x_cont_tilde
        self.m_label = m_label
        self.x = x

    def __len__(self):
        return len(self.x_categ_tilde)

    def __getitem__(self, idx):
        return (
            self.x_categ_tilde[idx],  # 扰动分类特征
            self.x_cont_tilde[idx],  # 扰动连续特征
            self.m_label[idx],  # 合并掩码
            self.x[idx]  # 原始特征（用于特征值预测）
        )


def get_masked_data(args, data_loader_func):
    """获取掩码数据"""
    # 加载数据集
    cat_dims, cat_idxs, con_idxs, train_dataset, valid_dataset, test_dataset, datasets_unlabel = data_loader_func(
        args.data)

    # 获取有标签和无标签数据
    if hasattr(train_dataset, 'get_data'):
        x_cat_l, x_con_l, y = train_dataset.get_data()
    else:
        # 对于DataLoader的情况
        train_loader = DataLoader(train_dataset, batch_size=len(train_dataset), shuffle=False)
        x_cat_l, x_con_l, y = next(iter(train_loader))
        x_cat_l = x_cat_l.numpy()
        x_con_l = x_con_l.numpy()

    if hasattr(datasets_unlabel, 'get_data'):
        x_cat_ul, x_con_ul = datasets_unlabel.get_data()
    else:
        unlabel_loader = DataLoader(datasets_unlabel, batch_size=len(datasets_unlabel), shuffle=False)
        x_cat_ul, x_con_ul = next(iter(unlabel_loader))
        x_cat_ul = x_cat_ul.numpy()
        x_con_ul = x_con_ul.numpy()

    # 合并数据
    x_cat = np.concatenate((x_cat_l, x_cat_ul), axis=0)
    x_con = np.concatenate((x_con_l, x_con_ul), axis=0)

    # 生成掩码和扰动数据
    p_m = args.p_m if hasattr(args, 'p_m') else 0.1

    m_cont = mask_generator(x_con, p_m=p_m)
    m_cont_label, x_cont_tilde = pretext_generator(m_cont, x_con)

    m_categ = mask_generator(x_cat, p_m=p_m)
    m_categ_label, x_categ_tilde = pretext_generator(m_categ, x_cat)

    # 合并掩码
    m_label = torch.cat((m_categ_label, m_cont_label), dim=1)

    # 合并原始特征（用于特征值预测）
    x = np.concatenate((x_cat, x_con), axis=1)
    x = torch.tensor(x, dtype=torch.float32)

    return x_categ_tilde, x_cont_tilde, m_label, x


def pre_train(args, data_loader_func):
    """预训练主函数"""
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    print(f"使用设备: {device}")

    # 获取掩码数据
    x_categ_tilde, x_cont_tilde, m_label, x = get_masked_data(args, data_loader_func)

    # 创建数据集和数据加载器
    dataset = MaskedDataset(x_categ_tilde, x_cont_tilde, m_label, x)
    dataloader = DataLoader(dataset, batch_size=args.batch_size, shuffle=True,drop_last=True)

    # 加载数据集信息
    cat_dims, cat_idxs, con_idxs, train_dataset, valid_dataset, test_dataset, datasets_unlabel = data_loader_func(
        args.data)

    # 创建模型
    model = PreTrainWrapper(args, cat_dims, len(con_idxs))
    model = model.to(device)

    # 检查是否已有预训练权重
    save_dir = f'save_model/pretrain/{args.data}'
    os.makedirs(save_dir, exist_ok=True)
    pretrain_path = os.path.join(save_dir, 'tabssl_pretrain.pth')

    # if os.path.exists(pretrain_path) and not args.force_retrain:
    #     print("找到已存在的预训练权重，加载中...")
    #     if model.load_model(pretrain_path):
    #         print("预训练权重加载成功")
    #         return model.tabssl.encoder
    #     else:
    #         print("加载失败，开始重新训练")

    # 设置优化器
    optimizer = torch.optim.Adam(model.pretrain_params(), lr=args.lr)

    # 训练循环
    model.train()
    for epoch in range(args.epochs):
        total_loss = 0.0
        total_mask_loss = 0.0
        total_feature_loss = 0.0

        progress_bar = tqdm(dataloader, desc=f'Epoch {epoch + 1}/{args.epochs}')
        for batch_idx, (x_cat, x_con, y_pos, y_val) in enumerate(progress_bar):
            # 移动到设备
            x_cat = x_cat.to(device).long()  # 分类特征需要long类型
            x_con = x_con.to(device).float()
            y_pos = y_pos.to(device).float()
            y_val = y_val.to(device).float()  # 添加维度匹配输出

            # 数据检查
            if torch.isnan(x_con).any() or torch.isinf(x_con).any():
                print(f"警告: 批次 {batch_idx} 包含无效值")
                continue

            # 前向传播
            optimizer.zero_grad()
            loss, mask_pred, feature_pred = model(x_cat, x_con, y_pos, y_val)

            # 反向传播
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            optimizer.step()

            # 记录损失
            total_loss += loss.item()

            # 更新进度条
            progress_bar.set_postfix({
                'loss': f'{loss.item():.4f}',
                'avg_loss': f'{total_loss / (batch_idx + 1):.4f}'
            })

        # 打印epoch统计
        avg_loss = total_loss / len(dataloader)
        print(f'Epoch {epoch + 1}/{args.epochs} - 平均损失: {avg_loss:.4f}')

        # 保存检查点
        if (epoch + 1) % args.save_interval == 0:
            checkpoint_path = os.path.join(save_dir, f'checkpoint_epoch_{epoch + 1}.pth')
            torch.save({
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'loss': avg_loss,
            }, checkpoint_path)
            print(f"检查点已保存: {checkpoint_path}")

    # 保存最终模型
    model.save_weights(save_dir)
    print(f"预训练完成，模型已保存到: {pretrain_path}")




def main():
    parser = argparse.ArgumentParser(description='TabSSL预训练')

    # 数据参数
    parser.add_argument('--data', type=str, default='SMIC',
                        choices=['SMIC', 'ICSprout', 'HTSGA18', 'MNIST'],
                        help='数据集名称')
    parser.add_argument('--dim_out', type=int, default=1,help='输出头维度')
    # 模型参数
    parser.add_argument('--dim', type=int, default=32, help='特征维度')
    parser.add_argument('--depth', type=int, default=6, help='Transformer深度')
    parser.add_argument('--heads', type=int, default=8, help='注意力头数')
    parser.add_argument('--dim_head', type=int, default=16, help='每个头的维度')
    parser.add_argument('--attn_dropout', type=float, default=0.0, help='注意力dropout')
    parser.add_argument('--ff_dropout', type=float, default=0.0, help='前馈网络dropout')
    parser.add_argument('--gate_type', type=str, default='headwise',
                        choices=['none', 'headwise', 'elementwise'], help='门控类型')
    parser.add_argument('--use_qk_norm', action='store_true', help='是否使用QK归一化')

    # 预训练参数
    parser.add_argument('--pretrain',type=bool,default=True,help='是否预训练')
    parser.add_argument('--p_m', type=float, default=0.1, help='掩码概率')
    parser.add_argument('--alpha', type=float, default=0.01, help='特征损失权重')

    # 训练参数
    parser.add_argument('--batch_size', type=int, default=32, help='批大小')
    parser.add_argument('--epochs', type=int, default=100, help='训练轮数')
    parser.add_argument('--lr', type=float, default=0.001, help='学习率')
    parser.add_argument('--save_interval', type=int, default=10, help='保存间隔')
    parser.add_argument('--force_retrain', action='store_true', help='强制重新训练')

    args = parser.parse_args()

    # 导入数据加载函数
    from dataset.dataload import load_dataset

    # 运行预训练
    pre_train(args, load_dataset)

    print("预训练完成！")


if __name__ == "__main__":
    main()