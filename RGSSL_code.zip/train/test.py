from pathlib import Path as _Path
import sys as _sys
_PROJECT_ROOT = _Path(__file__).resolve().parents[1]
if str(_PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_PROJECT_ROOT))

import torch
from torch.utils.data import DataLoader
from models.semi_supervised import *
from dataset.dataload import load_dataset
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score


def test(args):
    cat_dims, cat_idxs, con_idxs, train_dataset,valid_dataset,test_dataset,datasets_unlabel = load_dataset(data=args.data)
    bsize = args.batch_size
    val_loader = DataLoader(valid_dataset, batch_size=bsize, shuffle=False)
    test_loader = DataLoader(test_dataset, batch_size=bsize, shuffle=False)
    # 获取无标签数据集
    #设置训练论述
    #计算样本总共个数
    model = TabSSL(
        categories=tuple(cat_dims),
        num_continuous=len(con_idxs),
        input_size=len(cat_dims) + len(con_idxs),
        semi_cons_w=args.semi_cons_w,
        p_m=args.p_m,
        gama=args.gama,
        alpha=args.alpha,
        beta=args.beta,
        augloss_w=args.augloss_w,
        pretrain=args.pretrain,
        filepath=args.encoder_path,
        dim=args.dim,
        depth=args.depth,
        heads=args.heads,
        dim_head=args.dim_head,
        num_special_tokens=args.num_special_tokens,
        attn_dropout=args.attn_dropout,
        ff_dropout=args.ff_dropout,
        y_dim=args.y_dim,
    )
    model.load_state_dict(torch.load(f'save_model/{args.data}/model.pt'))
    model.eval()
    #获取模型参数
    #记录测试步骤
    num_samples = 0
    all_preds = []
    all_labels = []
    with torch.no_grad():
        for x_cat, x_con, label in test_loader:
            # 数据转移到设备
            x_cat = x_cat.long()
            x_con = x_con.float()
            label = label.float()
            # 模型预测
            pred = model.predict(x_cat, x_con)
            # 收集预测和标签
            # 展平batch维度
            all_preds.append(pred.cpu().numpy().reshape(-1))  # 展平为1D
            all_labels.append(label.cpu().numpy().reshape(-1))

        # 合并所有样本
        all_preds = np.concatenate(all_preds)
        all_labels = np.concatenate(all_labels)
        num_samples += len(label)
        mse = mean_squared_error(all_labels, all_preds)
        mae = mean_absolute_error(all_labels, all_preds)
        rmse = np.sqrt(mse)
        r2 = r2_score(all_labels, all_preds)

        return {
            'MSE': mse,
            'MAE': mae,
            'RMSE': rmse,
            'R2': r2,
            'num_samples': num_samples
        }
