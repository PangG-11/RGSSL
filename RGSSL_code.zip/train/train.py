from pathlib import Path as _Path
import sys as _sys
_PROJECT_ROOT = _Path(__file__).resolve().parents[1]
if str(_PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_PROJECT_ROOT))

import argparse
import copy
import numpy as np
import torch
import torch.nn as nn

from torch.utils.data import DataLoader
from tqdm import tqdm
import warnings
from models.semi_supervised import TabSSL
import os
import json
from sklearn.metrics import (
    accuracy_score,
    f1_score,
    mean_absolute_error,
    mean_squared_error,
    r2_score,
)
import matplotlib.pyplot as plt
warnings.filterwarnings('ignore')
os.environ['CUDA_LAUNCH_BLOCKING'] = '1'


class SemiSupervisedTrainer:
    """Semi-supervised trainer."""

    def __init__(self, args, model, categories, num_continuous, device='cuda'):
        self.args = args
        self.device = device
        self.categories = categories
        self.num_continuous = num_continuous

        self.model = model.to(device)
        self.ema_model = copy.deepcopy(self.model).to(device)
        self.ema_model.eval()
        for param in self.ema_model.parameters():
            param.requires_grad_(False)
        self.ema_decay = getattr(args, 'ema_decay', 0.999)
        self.task_type = getattr(args, 'task_type', 'regression')
        self.is_classification = self.task_type == 'classification'

        self.supervised_loss_fn = nn.CrossEntropyLoss() if self.is_classification else nn.MSELoss()
        self.consistency_loss_fn = nn.MSELoss()

        self.optimizer = torch.optim.Adam(
            self.model.parameters(),
            lr=args.lr,
            weight_decay=args.weight_decay
        )

        self.scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            self.optimizer,
            T_max=args.epochs
        )

        self.consistency_weight = args.consistency_weight
        self.weak_prediction_number = max(1, int(getattr(args, 'weak_prediction_number', 5)))
        self.tau_u = float(getattr(args, 'tau_u', 0.2))
        self.consistency_eps = float(getattr(args, 'consistency_eps', 1e-8))

        self.save_dir = f'save_model/semi_supervised/{args.data}'
        os.makedirs(self.save_dir, exist_ok=True)

        self.history = {
            'train_supervised_loss': [],
            'train_consistency_loss': [],
            'train_total_loss': [],
            'confidence_keep_ratio': [],
            'uncertainty_mean': [],
            'uncertainty_std': [],
            'val_loss': [],
            'val_r2': [],
            'val_mae': [],
            'val_rmse': []
        }

    def compute_supervised_loss(self, pred, target):
        """Compute supervised loss for regression or classification."""
        if self.is_classification:
            return self.supervised_loss_fn(pred, target.view(-1).long())
        return self.supervised_loss_fn(pred, target.float())

    def compute_consistency_loss(self, student_pred, teacher_pred):
        """Compute EMA consistency loss for logits or regression outputs."""
        if self.is_classification:
            student_prob = torch.softmax(student_pred, dim=1)
            teacher_prob = torch.softmax(teacher_pred.detach(), dim=1)
            return self.consistency_loss_fn(student_prob, teacher_prob)
        return self.consistency_loss_fn(student_pred, teacher_pred.detach())

    def compute_uncertainty_filtered_consistency_loss(self, x_cat_ul, x_con_ul):
        """Compute RGSSL consistency loss with K weak predictions and tau_u filtering."""
        student_strong = self.model.get_strong_output(x_cat_ul, x_con_ul)

        with torch.no_grad():
            weak_predictions = [
                self.ema_model.get_weak_output(x_cat_ul, x_con_ul)
                for _ in range(self.weak_prediction_number)
            ]
            weak_predictions = torch.stack(weak_predictions, dim=0)

            if self.is_classification:
                weak_probs = torch.softmax(weak_predictions, dim=-1)
                pseudo_target = weak_probs.mean(dim=0)
                uncertainty = weak_probs.std(dim=0, unbiased=False).mean(dim=-1, keepdim=True)
            else:
                pseudo_target = weak_predictions.mean(dim=0)
                uncertainty = weak_predictions.std(dim=0, unbiased=False)

            mask = (uncertainty <= self.tau_u).float()

        if self.is_classification:
            student_prob = torch.softmax(student_strong, dim=1)
            per_sample_loss = torch.mean((student_prob - pseudo_target.detach()) ** 2, dim=1, keepdim=True)
        else:
            per_sample_loss = (student_strong - pseudo_target.detach()) ** 2

        consistency_loss = (per_sample_loss * mask).sum() / (mask.sum() + self.consistency_eps)
        stats = {
            'confidence_keep_ratio': mask.mean().item(),
            'uncertainty_mean': uncertainty.mean().item(),
            'uncertainty_std': uncertainty.std(unbiased=False).item(),
        }
        return consistency_loss, stats

    def metric_name(self):
        return 'Accuracy' if self.is_classification else 'R2'

    def format_metrics(self, prefix, metrics):
        if self.is_classification:
            return (
                f"{prefix} Accuracy: {metrics['accuracy']:.4f}, "
                f"Macro F1: {metrics['macro_f1']:.4f}, "
                f"Weighted F1: {metrics['weighted_f1']:.4f}"
            )
        return (
            f"{prefix} R2 {metrics['r2']:.4f}, "
            f"{prefix} MAE: {metrics['mae']:.4f}, "
            f"{prefix} RMSE: {metrics['rmse']:.4f}"
        )

    def primary_metric(self, metrics):
        return metrics['accuracy'] if self.is_classification else metrics['r2']

    def append_validation_metrics(self, metrics):
        self.history['val_loss'].append(1 - self.primary_metric(metrics))
        if self.is_classification:
            self.history.setdefault('val_accuracy', []).append(metrics['accuracy'])
            self.history.setdefault('val_macro_f1', []).append(metrics['macro_f1'])
            self.history.setdefault('val_weighted_f1', []).append(metrics['weighted_f1'])
        else:
            self.history.setdefault('val_r2', []).append(metrics['r2'])
            self.history.setdefault('val_mae', []).append(metrics['mae'])
            self.history.setdefault('val_rmse', []).append(metrics['rmse'])

    def train_epoch_supervised(self, labeled_loader, epoch):
        """Train one supervised epoch."""
        self.model.train()

        total_supervised_loss = 0
        num_batches = 0

        pbar = tqdm(labeled_loader, desc=f'Epoch {epoch} (Supervised)')

        for x_cat_l, x_con_l, y_l in pbar:
            x_cat_l = x_cat_l.to(self.device).long()
            x_con_l = x_con_l.to(self.device).float()
            y_l = y_l.to(self.device).float()

            pred_l = self.model(x_cat_l, x_con_l)

            supervised_loss = self.compute_supervised_loss(pred_l, y_l)

            self.optimizer.zero_grad()
            supervised_loss.backward()

            torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)

            self.optimizer.step()
            self.update_ema_model()

            total_supervised_loss += supervised_loss.item()
            num_batches += 1

            pbar.set_postfix({
                'sup_loss': f'{supervised_loss.item():.4f}'
            })

        avg_supervised_loss = total_supervised_loss / num_batches if num_batches > 0 else 0

        return avg_supervised_loss

    def train_supervised(self, labeled_dataset, val_dataset, test_dataset=None):
        """Run supervised training."""
        labeled_loader = DataLoader(
            labeled_dataset,
            batch_size=self.args.batch_size,
            shuffle=True,
            num_workers=getattr(self.args, 'num_workers', 0),
            drop_last=False
        )

        val_loader = DataLoader(
            val_dataset,
            batch_size=self.args.batch_size * 2,
            shuffle=False,
            num_workers=getattr(self.args, 'num_workers', 0)
        )

        if test_dataset is not None:
            test_loader = DataLoader(
                test_dataset,
                batch_size=self.args.batch_size * 2,
                shuffle=False,
                num_workers=getattr(self.args, 'num_workers', 0)
            )

        self.save_dir = f'save_model/supervised/{self.args.data}'
        os.makedirs(self.save_dir, exist_ok=True)

        self.history = {
            'train_loss': [],
            'val_loss': [],
            'val_r2': [],
            'val_mae': [],
            'val_rmse': []
        }

        best_val_r2 = -float('inf')
        best_epoch = 0

        print("\nStart supervised training")
        print(f"Labeled samples: {len(labeled_dataset)}")
        print(f"Validation samples: {len(val_dataset)}")
        if test_dataset:
            print(f"Test samples: {len(test_dataset)}")
        print(f"Labeled batches: {len(labeled_loader)}")

        for epoch in range(1, self.args.epochs + 1):
            print(f"\nEpoch {epoch}/{self.args.epochs}")

            train_loss = self.train_epoch_supervised(labeled_loader, epoch)

            self.scheduler.step()

            val_metrics, _, _ = self.evaluate(val_loader)
            val_score = self.primary_metric(val_metrics)

            self.history['train_loss'].append(train_loss)
            self.append_validation_metrics(val_metrics)

            print(f"Train Loss: {train_loss:.4f}")
            print(self.format_metrics("Val", val_metrics))
            print(f"Learning Rate: {self.scheduler.get_last_lr()[0]:.6f}")

            if val_score > best_val_r2:
                best_val_r2 = val_score
                best_epoch = epoch
                self.save_model('best_model.pth')
                print(f"Saved best model, {self.metric_name()}: {val_score:.4f}")

            if epoch % self.args.save_interval == 0:
                self.save_model(f'checkpoint_epoch_{epoch}.pth')

        self.load_model(os.path.join(self.save_dir, 'best_model.pth'))
        print(f"\nSupervised training finished. Best epoch: {best_epoch}, {self.metric_name()}: {best_val_r2:.4f}")

        if test_dataset is not None:
            test_metrics, test_pred, test_true = self.evaluate(test_loader)
            print("\nTest results")
            print(self.format_metrics("Test", test_metrics))

            test_results = {
                **{key: float(value) for key, value in test_metrics.items()},
                'task_type': self.task_type,
                'predictions': test_pred.tolist(),
                'targets': test_true.tolist()
            }
            with open(os.path.join(self.save_dir, 'test_results.json'), 'w') as f:
                json.dump(test_results, f, indent=2)

        self.save_model('final_model.pth')
        self.save_history()
        self.plot_training_history_supervised()

        return self.history

    @torch.no_grad()
    def update_ema_model(self):
        """Update teacher weights with exponential moving average."""
        for ema_param, param in zip(self.ema_model.parameters(), self.model.parameters()):
            ema_param.data.mul_(self.ema_decay).add_(param.data, alpha=1.0 - self.ema_decay)
        for ema_buffer, buffer in zip(self.ema_model.buffers(), self.model.buffers()):
            ema_buffer.copy_(buffer)

    def train_epoch(self, labeled_loader, unlabeled_loader, epoch):
        """Train one semi-supervised epoch."""
        self.model.train()

        total_supervised_loss = 0
        total_consistency_loss = 0
        total_loss = 0
        total_keep_ratio = 0
        total_uncertainty_mean = 0
        total_uncertainty_std = 0
        num_batches = 0

        if unlabeled_loader is None or len(unlabeled_loader) == 0:
            pbar = tqdm(labeled_loader, desc=f'Epoch {epoch} (Supervised only)')
            for x_cat_l, x_con_l, y_l in pbar:
                x_cat_l = x_cat_l.to(self.device).long()
                x_con_l = x_con_l.to(self.device).float()
                y_l = y_l.to(self.device).float()

                pred_l = self.model(x_cat_l, x_con_l)
                supervised_loss = self.compute_supervised_loss(pred_l, y_l)

                self.optimizer.zero_grad()
                supervised_loss.backward()

                torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)

                self.optimizer.step()
                self.update_ema_model()

                total_supervised_loss += supervised_loss.item()
                total_loss += supervised_loss.item()
                num_batches += 1

                pbar.set_postfix({
                    'sup_loss': f'{supervised_loss.item():.4f}'
                })

            avg_supervised_loss = total_supervised_loss / num_batches if num_batches > 0 else 0
            return avg_supervised_loss, 0, avg_supervised_loss, 0, 0, 0

        pbar = tqdm(zip(labeled_loader, unlabeled_loader),
                   total=min(len(labeled_loader), len(unlabeled_loader)),
                   desc=f'Epoch {epoch}')

        for (x_cat_l, x_con_l, y_l), (x_cat_ul, x_con_ul) in pbar:
            x_cat_l = x_cat_l.to(self.device).long()
            x_con_l = x_con_l.to(self.device).float()
            y_l = y_l.to(self.device).float()
            x_cat_ul = x_cat_ul.to(self.device).long()
            x_con_ul = x_con_ul.to(self.device).float()
            pred_l = self.model(x_cat_l, x_con_l)
            supervised_loss = self.compute_supervised_loss(pred_l, y_l)
            # EMA teacher gives K weak-view pseudo labels; tau_u keeps only stable unlabeled samples.
            Lu, confidence_stats = self.compute_uncertainty_filtered_consistency_loss(x_cat_ul, x_con_ul)
            loss = supervised_loss + self.consistency_weight * Lu

            self.optimizer.zero_grad()
            loss.backward()

            torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)

            self.optimizer.step()
            self.update_ema_model()

            total_supervised_loss += supervised_loss.item()
            total_consistency_loss += Lu.item()
            total_loss += loss.item()
            total_keep_ratio += confidence_stats['confidence_keep_ratio']
            total_uncertainty_mean += confidence_stats['uncertainty_mean']
            total_uncertainty_std += confidence_stats['uncertainty_std']
            num_batches += 1

            pbar.set_postfix({
                'sup_loss': f'{supervised_loss.item():.4f}',
                'cons_loss': f'{Lu.item():.4f}',
                'total_loss': f'{loss.item():.4f}',
                'keep': f"{confidence_stats['confidence_keep_ratio']:.3f}"
            })

        if num_batches > 0:
            avg_supervised_loss = total_supervised_loss / num_batches
            avg_consistency_loss = total_consistency_loss / num_batches
            avg_total_loss = total_loss / num_batches
            avg_keep_ratio = total_keep_ratio / num_batches
            avg_uncertainty_mean = total_uncertainty_mean / num_batches
            avg_uncertainty_std = total_uncertainty_std / num_batches
        else:
            avg_supervised_loss = avg_consistency_loss = avg_total_loss = 0
            avg_keep_ratio = avg_uncertainty_mean = avg_uncertainty_std = 0

        return (
            avg_supervised_loss,
            avg_consistency_loss,
            avg_total_loss,
            avg_keep_ratio,
            avg_uncertainty_mean,
            avg_uncertainty_std,
        )

    def evaluate(self, dataloader):
        """Evaluate the student model."""
        self.model.eval()

        all_predictions = []
        all_targets = []

        with torch.no_grad():
            for x_cat, x_con, y in dataloader:
                x_cat = x_cat.to(self.device).long()
                x_con = x_con.to(self.device).float()
                y = y.to(self.device).float()

                pred = self.model(x_cat, x_con)
                if self.is_classification:
                    pred_label = torch.argmax(pred, dim=1)
                    all_predictions.append(pred_label.cpu().numpy())
                    all_targets.append(y.view(-1).long().cpu().numpy())
                else:
                    all_predictions.append(pred.cpu().numpy())
                    all_targets.append(y.cpu().numpy())

        all_predictions = np.concatenate(all_predictions, axis=0)
        all_targets = np.concatenate(all_targets, axis=0)

        if self.is_classification:
            metrics = {
                'accuracy': accuracy_score(all_targets, all_predictions),
                'macro_f1': f1_score(all_targets, all_predictions, average='macro', zero_division=0),
                'weighted_f1': f1_score(all_targets, all_predictions, average='weighted', zero_division=0),
            }
        else:
            metrics = {
                'r2': r2_score(all_targets, all_predictions),
                'mae': mean_absolute_error(all_targets, all_predictions),
                'rmse': np.sqrt(mean_squared_error(all_targets, all_predictions)),
            }

        return metrics, all_predictions, all_targets

    def train(self, labeled_dataset, unlabeled_dataset, val_dataset, test_dataset=None):
        """Run semi-supervised training."""
        labeled_loader = DataLoader(
            labeled_dataset,
            batch_size=self.args.batch_size,
            shuffle=True,
            num_workers=getattr(self.args, 'num_workers', 0),
            drop_last=False
        )

        if len(unlabeled_dataset) > 0:
            unlabeled_loader = DataLoader(
                unlabeled_dataset,
                batch_size=self.args.batch_size * self.args.unlabeled_ratio,
                shuffle=True,
                num_workers=getattr(self.args, 'num_workers', 0),
                drop_last=True
            )
        else:
            unlabeled_loader = None

        val_loader = DataLoader(
            val_dataset,
            batch_size=self.args.batch_size * 2,
            shuffle=False,
            num_workers=getattr(self.args, 'num_workers', 0)
        )

        if test_dataset is not None:
            test_loader = DataLoader(
                test_dataset,
                batch_size=self.args.batch_size * 2,
                shuffle=False,
                num_workers=getattr(self.args, 'num_workers', 0)
            )

        best_val_r2 = -float('inf')
        best_epoch = 0

        print("\nStart semi-supervised training")
        print(f"Labeled samples: {len(labeled_dataset)}")
        print(f"Unlabeled samples: {len(unlabeled_dataset)}")
        print(f"Validation samples: {len(val_dataset)}")
        if test_dataset:
            print(f"Test samples: {len(test_dataset)}")
        print(f"Consistency weight: {self.consistency_weight}")
        print(f"Weak prediction number K: {self.weak_prediction_number}")
        print(f"Uncertainty threshold tau_u: {self.tau_u}")
        print(f"Weak noise std: {getattr(self.args, 'weak_noise_std', 0.01)}")
        print(f"Strong noise std: {getattr(self.args, 'strong_noise_std', 0.05)}")
        print(f"Unlabeled ratio: {self.args.unlabeled_ratio}")
        print(f"Labeled batches: {len(labeled_loader)}")
        if unlabeled_loader is None:
            print("Unlabeled batches: 0")
            print("No unlabeled samples found; training will use supervised loss only.")
        else:
            print(f"Unlabeled batches: {len(unlabeled_loader)}")

        for epoch in range(1, self.args.epochs + 1):
            print(f"\nEpoch {epoch}/{self.args.epochs}")

            if self.args.consistency_rampup > 0:
                self.consistency_weight = min(
                    self.args.consistency_weight,
                    self.args.consistency_weight * (epoch / self.args.consistency_rampup)
                )


            (
                train_sup_loss,
                train_cons_loss,
                train_total_loss,
                confidence_keep_ratio,
                uncertainty_mean,
                uncertainty_std,
            ) = self.train_epoch(
                labeled_loader, unlabeled_loader, epoch
            )

            self.scheduler.step()

            val_metrics, _, _ = self.evaluate(val_loader)
            val_score = self.primary_metric(val_metrics)

            self.history['train_supervised_loss'].append(train_sup_loss)
            self.history['train_consistency_loss'].append(train_cons_loss)
            self.history['train_total_loss'].append(train_total_loss)
            self.history['confidence_keep_ratio'].append(confidence_keep_ratio)
            self.history['uncertainty_mean'].append(uncertainty_mean)
            self.history['uncertainty_std'].append(uncertainty_std)
            self.append_validation_metrics(val_metrics)

            print(f"Train Supervised Loss: {train_sup_loss:.4f}")
            print(f"Train Consistency Loss: {train_cons_loss:.4f}")
            print(f"Train Total Loss: {train_total_loss:.4f}")
            print(f"Confidence Keep Ratio: {confidence_keep_ratio:.4f}")
            print(f"Uncertainty Mean: {uncertainty_mean:.6f}")
            print(f"Uncertainty Std: {uncertainty_std:.6f}")
            print(self.format_metrics("Val", val_metrics))
            print(f"Consistency Weight: {self.consistency_weight:.4f}")
            print(f"Learning Rate: {self.scheduler.get_last_lr()[0]:.6f}")

            if val_score > best_val_r2:
                best_val_r2 = val_score
                best_epoch = epoch
                self.save_model('best_model.pth')
                print(f"Saved best model, {self.metric_name()}: {val_score:.4f}")

            if epoch % self.args.save_interval == 0:
                self.save_model(f'checkpoint_epoch_{epoch}.pth')


        self.load_model(os.path.join(self.save_dir, 'best_model.pth'))
        print(f"\nTraining finished. Best epoch: {best_epoch}, {self.metric_name()}: {best_val_r2:.4f}")

        if test_dataset is not None:
            test_metrics, test_pred, test_true = self.evaluate(test_loader)
            print("\nTest results")
            print(self.format_metrics("Test", test_metrics))

            test_results = {
                **{key: float(value) for key, value in test_metrics.items()},
                'task_type': self.task_type,
                'predictions': test_pred.tolist(),
                'targets': test_true.tolist()
            }
            with open(os.path.join(self.save_dir, 'test_results.json'), 'w') as f:
                json.dump(test_results, f, indent=2)

        self.save_model('final_model.pth')
        self.save_history()
        self.plot_training_history()

        return self.history

    def save_model(self, filename):
        """Save a checkpoint."""
        save_path = os.path.join(self.save_dir, filename)
        torch.save({
            'model_state_dict': self.model.state_dict(),
            'ema_model_state_dict': self.ema_model.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'scheduler_state_dict': self.scheduler.state_dict(),
            'args': self.args,
            'categories': self.categories,
            'num_continuous': self.num_continuous,
            'history': self.history
        }, save_path)
        print(f"Saved model to {save_path}")

    def load_model(self, filepath):
        """Load a checkpoint."""
        if os.path.exists(filepath):
            checkpoint = torch.load(filepath, map_location=self.device, weights_only=False)
            self.model.load_state_dict(checkpoint['model_state_dict'])
            if 'ema_model_state_dict' in checkpoint:
                self.ema_model.load_state_dict(checkpoint['ema_model_state_dict'])
            else:
                self.ema_model.load_state_dict(checkpoint['model_state_dict'], strict=False)
            self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
            self.scheduler.load_state_dict(checkpoint['scheduler_state_dict'])
            self.history = checkpoint.get('history', self.history)
            print(f"Loaded model from {filepath}")
            return True
        return False

    def save_history(self):
        """Save training history."""
        history_path = os.path.join(self.save_dir, 'training_history.json')

        def convert_to_python_types(obj):
            if isinstance(obj, np.ndarray):
                return obj.tolist()
            elif isinstance(obj, np.float32) or isinstance(obj, np.float64):
                return float(obj)
            elif isinstance(obj, np.int32) or isinstance(obj, np.int64):
                return int(obj)
            elif isinstance(obj, dict):
                return {key: convert_to_python_types(value) for key, value in obj.items()}
            elif isinstance(obj, list):
                return [convert_to_python_types(item) for item in obj]
            else:
                return obj

        python_history = convert_to_python_types(self.history)

        with open(history_path, 'w') as f:
            json.dump(python_history, f, indent=2)
        print(f"Saved training history to {history_path}")

    def plot_training_history(self):
        """Plot semi-supervised training history."""
        fig, axes = plt.subplots(2, 2, figsize=(12, 10))

        axes[0, 0].plot(self.history['train_supervised_loss'], label='Supervised Loss')
        axes[0, 0].plot(self.history['train_consistency_loss'], label='Consistency Loss')
        axes[0, 0].plot(self.history['train_total_loss'], label='Total Loss')
        axes[0, 0].set_xlabel('Epoch')
        axes[0, 0].set_ylabel('Loss')
        axes[0, 0].set_title('Training Loss')
        axes[0, 0].legend()
        axes[0, 0].grid(True)

        axes[0, 1].plot(self.history['val_loss'], label='Validation Loss')
        axes[0, 1].set_xlabel('Epoch')
        axes[0, 1].set_ylabel('Loss')
        axes[0, 1].set_title('Validation Loss')
        axes[0, 1].legend()
        axes[0, 1].grid(True)

        if self.is_classification:
            axes[1, 0].plot(self.history.get('val_accuracy', []), label='Accuracy', color='green')
            axes[1, 0].plot(self.history.get('val_macro_f1', []), label='Macro F1', color='purple')
            axes[1, 0].set_ylabel('Classification Score')
            axes[1, 0].set_title('Validation Classification Metrics')
        else:
            axes[1, 0].plot(self.history.get('val_r2', []), label='R2', color='green')
            axes[1, 0].set_ylabel('R2 Score')
            axes[1, 0].set_title('Validation R2 Score')
        axes[1, 0].set_xlabel('Epoch')
        axes[1, 0].legend()
        axes[1, 0].grid(True)

        if self.is_classification:
            axes[1, 1].plot(self.history.get('val_weighted_f1', []), label='Weighted F1', color='orange')
            axes[1, 1].set_ylabel('Classification Score')
            axes[1, 1].set_title('Validation Weighted F1')
        else:
            axes[1, 1].plot(self.history.get('val_mae', []), label='MAE', color='orange')
            axes[1, 1].plot(self.history.get('val_rmse', []), label='RMSE', color='red')
            axes[1, 1].set_ylabel('Error')
            axes[1, 1].set_title('Validation Errors')
        axes[1, 1].set_xlabel('Epoch')
        axes[1, 1].legend()
        axes[1, 1].grid(True)

        plt.tight_layout()
        plot_path = os.path.join(self.save_dir, 'training_history.png')
        plt.savefig(plot_path, dpi=300, bbox_inches='tight')
        plt.close()
        print(f"Saved training plot to {plot_path}")

    def plot_training_history_supervised(self):
        """Plot supervised training history."""
        fig, axes = plt.subplots(2, 2, figsize=(12, 10))

        axes[0, 0].plot(self.history['train_loss'], label='Training Loss')
        axes[0, 0].set_xlabel('Epoch')
        axes[0, 0].set_ylabel('Loss')
        axes[0, 0].set_title('Training Loss')
        axes[0, 0].legend()
        axes[0, 0].grid(True)

        axes[0, 1].plot(self.history['val_loss'], label='Validation Loss')
        axes[0, 1].set_xlabel('Epoch')
        axes[0, 1].set_ylabel('Loss')
        axes[0, 1].set_title('Validation Loss')
        axes[0, 1].legend()
        axes[0, 1].grid(True)

        if self.is_classification:
            axes[1, 0].plot(self.history.get('val_accuracy', []), label='Accuracy', color='green')
            axes[1, 0].plot(self.history.get('val_macro_f1', []), label='Macro F1', color='purple')
            axes[1, 0].set_ylabel('Classification Score')
            axes[1, 0].set_title('Validation Classification Metrics')
        else:
            axes[1, 0].plot(self.history.get('val_r2', []), label='R2', color='green')
            axes[1, 0].set_ylabel('R2 Score')
            axes[1, 0].set_title('Validation R2 Score')
        axes[1, 0].set_xlabel('Epoch')
        axes[1, 0].legend()
        axes[1, 0].grid(True)

        if self.is_classification:
            axes[1, 1].plot(self.history.get('val_weighted_f1', []), label='Weighted F1', color='orange')
            axes[1, 1].set_ylabel('Classification Score')
            axes[1, 1].set_title('Validation Weighted F1')
        else:
            axes[1, 1].plot(self.history.get('val_mae', []), label='MAE', color='orange')
            axes[1, 1].plot(self.history.get('val_rmse', []), label='RMSE', color='red')
            axes[1, 1].set_ylabel('Error')
            axes[1, 1].set_title('Validation Errors')
        axes[1, 1].set_xlabel('Epoch')
        axes[1, 1].legend()
        axes[1, 1].grid(True)

        plt.tight_layout()
        plot_path = os.path.join(self.save_dir, 'training_history.png')
        plt.savefig(plot_path, dpi=300, bbox_inches='tight')
        plt.close()
        print(f"Saved training plot to {plot_path}")





def prepare_semi_supervised_data(data_loader_func, data_name, time_col=None):
    """Prepare semi-supervised datasets."""
    cat_dims, cat_idxs, con_idxs, train_dataset, valid_dataset, test_dataset, unlabel_dataset = data_loader_func(
        data_name,
        time_col=time_col,
    )

    return cat_dims, con_idxs, train_dataset, unlabel_dataset, valid_dataset, test_dataset


def configure_task_from_metadata(args):
    """Set task type and output dimension from processed dataset metadata."""
    meta_path = os.path.join("data_processed", args.data, f"{args.data}_meta.json")
    meta = {}
    if os.path.exists(meta_path):
        with open(meta_path, "r", encoding="utf-8") as f:
            meta = json.load(f)

    if getattr(args, "task_type", "auto") == "auto":
        args.task_type = meta.get("task_type", "regression")

    if args.task_type == "classification":
        num_classes = getattr(args, "num_classes", None) or meta.get("num_classes")
        if num_classes is None:
            raise ValueError(
                "Classification task requires --num_classes or num_classes in metadata."
            )
        args.num_classes = int(num_classes)
        args.dim_out = int(num_classes)
    else:
        args.task_type = "regression"
        args.dim_out = 1

    print(f"Task type: {args.task_type}")
    print(f"Output dimension: {args.dim_out}")


def run_semi_supervised_training(args, cat_dims, con_idxs, labeled_dataset, unlabeled_dataset, val_dataset,
                                 test_dataset):
    """Run semi-supervised or supervised-only training."""
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")

    model = TabSSL(
        args=args,
        categories=cat_dims,
        num_continuous=len(con_idxs)
    )
    model.to(device)

    pretrain_path = f'save_model/pretrain/{args.data}/tabssl_pretrain.pth'
    if os.path.exists(pretrain_path):
        model.load_state_dict(torch.load(pretrain_path, map_location=device), strict=False)
        print(f"Loaded pretrained weights from {pretrain_path}")

    trainer = SemiSupervisedTrainer(args, model, cat_dims, len(con_idxs), device)

    if getattr(args, 'supervised_only', False):
        return trainer.train_supervised(
            labeled_dataset=labeled_dataset,
            val_dataset=val_dataset,
            test_dataset=test_dataset
        )

    history = trainer.train(
        labeled_dataset=labeled_dataset,
        unlabeled_dataset=unlabeled_dataset,
        val_dataset=val_dataset,
        test_dataset=test_dataset
    )

    return history


def train(args):


    from dataset.dataload import load_dataset

    if args.run_pretrain:
        print("=" * 60)
        print("Starting pretraining...")
        print("=" * 60)

        pretrain_args = argparse.Namespace(
            data=args.data,
            dim=args.dim,
            depth=args.depth,
            heads=args.heads,
            dim_head=args.dim_head,
            block_size=getattr(args, 'block_size', 8),
            dim_out=args.dim_out,
            attn_dropout=args.attn_dropout,
            ff_dropout=args.ff_dropout,
            gate_type=args.gate_type,
            use_qk_norm=args.use_qk_norm,
            time_column=getattr(args, 'time_column', None),
            pretrain=True,
            p_m=args.p_m,
            alpha=args.alpha,
            batch_size=args.batch_size,
            epochs=50,
            lr=args.lr,
            save_interval=args.save_interval,
            force_retrain=False
        )

        from pretrain import pre_train
        pre_train(pretrain_args, load_dataset)
        print("Pretraining finished")
        print("=" * 60)

    print("\n" + "=" * 60)
    print("Preparing semi-supervised data...")
    print("=" * 60)
    configure_task_from_metadata(args)

    cat_dims, con_idxs, labeled_dataset, unlabeled_dataset, val_dataset, test_dataset = prepare_semi_supervised_data(
        load_dataset, args.data, time_col=getattr(args, 'time_column', None)
    )

    print("\n" + "=" * 60)
    print("Starting semi-supervised training...")
    print("=" * 60)

    history = run_semi_supervised_training(
        args, cat_dims, con_idxs, labeled_dataset, unlabeled_dataset, val_dataset, test_dataset
    )

    print("\n" + "=" * 60)
    print("Training finished")
    print("=" * 60)

    if getattr(args, 'supervised_only', False):
        save_dir = f'save_model/supervised/{args.data}'
    else:
        save_dir = f'save_model/semi_supervised/{args.data}'
    os.makedirs(save_dir, exist_ok=True)

    with open(os.path.join(save_dir, 'training_args.json'), 'w') as f:
        json.dump(vars(args), f, indent=2)

    print(f"All results saved to {save_dir}")
 

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='TabSSL semi-supervised training')
    parser.add_argument('--data', type=str, default='SMIC',
                        help='Dataset name')
    parser.add_argument('--dim', type=int, default=256, help='Hidden feature dimension')
    parser.add_argument('--depth', type=int, default=6, help='Transformer depth')
    parser.add_argument('--heads', type=int, default=8, help='Number of attention heads')
    parser.add_argument('--dim_head', type=int, default=16, help='Dimension per attention head')
    parser.add_argument('--block_size', type=int, default=8,
                        help='Gated_TransRes attention-residual block size')
    parser.add_argument('--task_type', type=str, default='auto',
                        choices=['auto', 'regression', 'classification'],
                        help='Task type')
    parser.add_argument('--num_classes', type=int, default=None,
                        help='Number of classes for classification')
    parser.add_argument('--dim_out', type=int, default=1, help='Output dimension')
    parser.add_argument('--attn_dropout', type=float, default=0.0, help='Attention dropout')
    parser.add_argument('--ff_dropout', type=float, default=0.0, help='Feed-forward dropout')
    parser.add_argument('--gate_type', type=str, default='headwise',
                        choices=['none', 'headwise', 'elementwise'], help='Attention gate type')
    parser.add_argument('--use_qk_norm', action='store_true', help='Use QK normalization')
    parser.add_argument('--time_column', type=str, default=None,
                        help='Timestamp column used for chronological splitting')
    parser.add_argument('--pretrain', type=bool, default=False, help='Use pretrained weights')
    parser.add_argument('--run_pretrain', action='store_true', help='Run pretraining before training')
    parser.add_argument('--p_m', type=float, default=0.1, help='Masking probability')
    parser.add_argument('--alpha', type=float, default=0.01, help='Feature reconstruction loss weight')
    parser.add_argument('--batch_size', type=int, default=100, help='Labeled batch size')
    parser.add_argument('--epochs', type=int, default=500, help='Number of training epochs')
    parser.add_argument('--lr', type=float, default=0.001, help='Learning rate')
    parser.add_argument('--weight_decay', type=float, default=1e-5, help='Weight decay')
    parser.add_argument('--save_interval', type=int, default=10, help='Checkpoint interval')
    parser.add_argument('--unlabeled_ratio', type=int, default=3,
                        help='Unlabeled batch size multiplier')
    parser.add_argument('--consistency_weight', type=float, default=0.2,
                        help='Regression consistency loss weight')
    parser.add_argument('--consistency_rampup', type=int, default=50,
                        help='Epochs used to ramp up consistency weight')
    parser.add_argument('--weak_prediction_number', type=int, default=5,
                        help='Number of stochastic weak-view predictions K')
    parser.add_argument('--tau_u', type=float, default=0.2,
                        help='Uncertainty threshold for unlabeled confidence masking')
    parser.add_argument('--weak_noise_std', type=float, default=0.01,
                        help='Noise scale for weak feature perturbation')
    parser.add_argument('--strong_noise_std', type=float, default=0.05,
                        help='Noise scale for strong feature perturbation')
    parser.add_argument('--noise_type', type=str, default='gaussian',
                        choices=['gaussian', 'uniform', 'bernoulli', 'none'],
                        help='Feature perturbation type')
    parser.add_argument('--consistency_eps', type=float, default=1e-8,
                        help='Small denominator constant for masked consistency loss')
    parser.add_argument('--ema_decay', type=float, default=0.999,
                        help='EMA teacher decay')
    parser.add_argument('--eval_freq', type=int, default=5, help='Evaluation frequency')
    args = parser.parse_args()
    train(args)
