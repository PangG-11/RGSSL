import argparse
import csv
from pathlib import Path

import pandas as pd

try:
    from dataset.time_split import chronological_sort
except ModuleNotFoundError:
    from time_split import chronological_sort


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_SOURCE_DIR = ROOT / "data" / "smicwat_4varsize_811_r2_gt_0p6"


def build_parser():
    parser = argparse.ArgumentParser(description="Create label75 splits for SMICWAT varsize 811 data.")
    parser.add_argument("--source_dir", type=str, default=str(DEFAULT_SOURCE_DIR))
    parser.add_argument("--dataset_ids", type=int, nargs="+", default=[1, 2, 3, 4])
    parser.add_argument("--label_ratio", type=float, default=0.75)
    parser.add_argument("--time_column", type=str, default=None)
    parser.add_argument("--seed", type=int, default=None,
                        help="Deprecated; chronological splitting does not shuffle rows")
    parser.add_argument("--target_col", type=str, default="yield")
    return parser


def create_label75_split(source_dir, dataset_id, label_ratio, target_col, time_column=None):
    train_file = source_dir / f"dataset_{dataset_id}_train.csv"
    if not train_file.exists():
        raise FileNotFoundError(f"Missing train file: {train_file}")

    train_df = pd.read_csv(train_file)
    if target_col not in train_df.columns:
        raise ValueError(f"Missing target column {target_col} in {train_file}")

    ordered, resolved_time_col = chronological_sort(train_df, time_column)
    if resolved_time_col is not None:
        ordered = ordered.drop(columns=[resolved_time_col])

    labeled_count = int(round(len(ordered) * label_ratio))
    labeled_df = ordered.iloc[:labeled_count].reset_index(drop=True)
    unlabel_df = ordered.iloc[labeled_count:].drop(columns=[target_col]).reset_index(drop=True)

    tag = f"label{int(round(label_ratio * 100))}"
    labeled_file = source_dir / f"dataset_{dataset_id}_{tag}_labeled.csv"
    unlabel_file = source_dir / f"dataset_{dataset_id}_{tag}_unlabel.csv"
    labeled_df.to_csv(labeled_file, index=False)
    unlabel_df.to_csv(unlabel_file, index=False)

    return {
        "dataset": f"dataset_{dataset_id}",
        "label_ratio": label_ratio,
        "labeled_rows": len(labeled_df),
        "unlabeled_rows": len(unlabel_df),
        "split_strategy": "chronological",
        "time_column": resolved_time_col or "source_order",
        "labeled_file": str(labeled_file),
        "unlabel_file": str(unlabel_file),
    }


def append_manifest_rows(source_dir, rows):
    manifest_file = source_dir / "label_ratio_manifest.csv"
    existing = []
    if manifest_file.exists():
        existing_df = pd.read_csv(manifest_file)
        existing = existing_df.to_dict("records")

    keys_to_replace = {(row["dataset"], float(row["label_ratio"])) for row in rows}
    kept = [
        row for row in existing
        if (row.get("dataset"), float(row.get("label_ratio"))) not in keys_to_replace
    ]
    combined = kept + rows
    combined = sorted(combined, key=lambda row: (row["dataset"], float(row["label_ratio"])))

    with manifest_file.open("w", encoding="utf-8", newline="") as f:
        fieldnames = [
            "dataset", "label_ratio", "labeled_rows", "unlabeled_rows",
            "split_strategy", "time_column", "labeled_file", "unlabel_file"
        ]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(combined)


def main():
    args = build_parser().parse_args()
    source_dir = Path(args.source_dir)
    rows = []
    for dataset_id in args.dataset_ids:
        row = create_label75_split(
            source_dir=source_dir,
            dataset_id=dataset_id,
            label_ratio=args.label_ratio,
            target_col=args.target_col,
            time_column=args.time_column,
        )
        rows.append(row)
        print(
            f"{row['dataset']} label75: labeled={row['labeled_rows']}, "
            f"unlabeled={row['unlabeled_rows']}"
        )

    append_manifest_rows(source_dir, rows)
    print(f"Updated manifest: {source_dir / 'label_ratio_manifest.csv'}")


if __name__ == "__main__":
    main()
