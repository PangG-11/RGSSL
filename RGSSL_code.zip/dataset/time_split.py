"""Utilities for leakage-safe chronological dataset splitting."""

from __future__ import annotations

import warnings

import numpy as np
import pandas as pd


DEFAULT_TIME_COLUMNS = (
    "START_TIME",
    "LOAD_TIME",
    "TEST_DAY",
    "timestamp",
    "datetime",
    "date",
    "time",
)

CHRONOLOGICAL_SEMI_SUPERVISED_STRATEGY = (
    "chronological_labeled_train_valid_unlabeled_train_test"
)


def resolve_time_column(df: pd.DataFrame, time_column: str | None = None) -> str | None:
    """Resolve an explicit or conventional time column, case-insensitively."""
    by_lower = {str(column).lower(): column for column in df.columns}

    if time_column:
        resolved = by_lower.get(time_column.lower())
        if resolved is None:
            raise ValueError(
                f"Time column {time_column!r} was not found. "
                f"Available columns: {list(df.columns)}"
            )
        return resolved

    for candidate in DEFAULT_TIME_COLUMNS:
        resolved = by_lower.get(candidate.lower())
        if resolved is not None:
            return resolved
    return None


def chronological_sort(
    df: pd.DataFrame,
    time_column: str | None = None,
) -> tuple[pd.DataFrame, str | None]:
    """Return rows in ascending time order using a stable sort.

    If no time column is present, source row order is preserved.  This fallback
    is deterministic and intentionally never shuffles the data.
    """
    resolved = resolve_time_column(df, time_column)
    if resolved is None:
        warnings.warn(
            "No time column was found; preserving source row order for the "
            "chronological split. Pass --time_column to enforce a specific column.",
            RuntimeWarning,
            stacklevel=2,
        )
        return df.reset_index(drop=True), None

    parsed_time = pd.to_datetime(df[resolved], errors="coerce")
    if not parsed_time.notna().any():
        raise ValueError(f"Time column {resolved!r} contains no parseable timestamps")

    ordered = df.copy()
    ordered["__split_time"] = parsed_time
    ordered["__source_order"] = np.arange(len(ordered))
    ordered = ordered.sort_values(
        ["__split_time", "__source_order"],
        kind="mergesort",
        na_position="last",
    )
    ordered = ordered.drop(columns=["__split_time", "__source_order"])
    return ordered.reset_index(drop=True), resolved


def chronological_train_valid_test_split(
    X: pd.DataFrame,
    y: pd.Series,
    train_ratio: float = 0.70,
    valid_ratio: float = 0.10,
):
    """Split aligned, time-ordered samples into past/present/future blocks."""
    if len(X) != len(y):
        raise ValueError("X and y must contain the same number of rows")
    if len(X) < 3:
        raise ValueError("At least three labeled rows are required for chronological splitting")
    if train_ratio <= 0 or valid_ratio <= 0 or train_ratio + valid_ratio >= 1:
        raise ValueError("train_ratio and valid_ratio must be positive and sum to less than one")

    row_count = len(X)
    train_end = max(1, min(int(row_count * train_ratio), row_count - 2))
    valid_end = max(
        train_end + 1,
        min(int(row_count * (train_ratio + valid_ratio)), row_count - 1),
    )

    X_train = X.iloc[:train_end].copy()
    X_valid = X.iloc[train_end:valid_end].copy()
    X_test = X.iloc[valid_end:].copy()
    y_train = y.iloc[:train_end].copy()
    y_valid = y.iloc[train_end:valid_end].copy()
    y_test = y.iloc[valid_end:].copy()
    return X_train, X_valid, X_test, y_train, y_valid, y_test


def chronological_semi_supervised_split(
    df: pd.DataFrame,
    label_size: int,
    unlabel_size: int,
    train_ratio: float = 0.70,
    valid_ratio: float = 0.10,
):
    """Create train -> valid -> unlabeled -> test chronological blocks.

    ``label_size`` is the total number of labeled rows across train, validation,
    and test. ``unlabel_size`` is inserted between validation and test so the
    held-out test set is always the latest time block.
    """
    if label_size < 3:
        raise ValueError("label_size must be at least three")
    if unlabel_size < 0:
        raise ValueError("unlabel_size cannot be negative")
    if train_ratio <= 0 or valid_ratio <= 0 or train_ratio + valid_ratio >= 1:
        raise ValueError("train_ratio and valid_ratio must be positive and sum to less than one")
    required_rows = label_size + unlabel_size
    if len(df) < required_rows:
        raise ValueError(
            f"Chronological split requires {required_rows} rows, but only "
            f"{len(df)} are available"
        )

    train_count = max(1, min(int(label_size * train_ratio), label_size - 2))
    valid_end_within_labeled = max(
        train_count + 1,
        min(int(label_size * (train_ratio + valid_ratio)), label_size - 1),
    )
    valid_count = valid_end_within_labeled - train_count
    test_count = label_size - train_count - valid_count

    train_end = train_count
    valid_end = train_end + valid_count
    unlabel_end = valid_end + unlabel_size
    test_end = unlabel_end + test_count

    train_df = df.iloc[:train_end].copy().reset_index(drop=True)
    valid_df = df.iloc[train_end:valid_end].copy().reset_index(drop=True)
    unlabel_df = df.iloc[valid_end:unlabel_end].copy().reset_index(drop=True)
    test_df = df.iloc[unlabel_end:test_end].copy().reset_index(drop=True)
    return train_df, valid_df, unlabel_df, test_df
