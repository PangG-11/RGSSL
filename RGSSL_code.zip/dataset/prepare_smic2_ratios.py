import argparse
import json
import shutil
from pathlib import Path

import pandas as pd

try:
    from dataset.time_split import (
        CHRONOLOGICAL_SEMI_SUPERVISED_STRATEGY,
        chronological_sort,
    )
except ModuleNotFoundError:
    from time_split import (
        CHRONOLOGICAL_SEMI_SUPERVISED_STRATEGY,
        chronological_sort,
    )


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_RATIOS = [0.05, 0.50, 1.00]


def build_parser():
    parser = argparse.ArgumentParser(
        description="Create SMIC2 semi-supervised splits with different labeled ratios."
    )
    parser.add_argument(
        "--source_dir",
        type=str,
        default=str(ROOT / "data_processed" / "smic2"),
        help="Directory containing smic_train.csv, smic_unlabel.csv, smic_valid.csv, and smic_test.csv",
    )
    parser.add_argument(
        "--output_root",
        type=str,
        default=str(ROOT / "data_processed"),
        help="Root directory where split folders will be created",
    )
    parser.add_argument(
        "--ratios",
        type=float,
        nargs="+",
        default=DEFAULT_RATIOS,
        help="Labeled ratios to generate, for example: 0.05 0.5 1.0",
    )
    parser.add_argument("--target_col", type=str, default="yield", help="Regression target column")
    parser.add_argument("--time_column", type=str, default=None)
    parser.add_argument("--seed", type=int, default=None,
                        help="Deprecated; chronological splitting does not shuffle rows")
    return parser


def ratio_to_name(ratio):
    return f"smic2_{int(round(ratio * 100))}"


def infer_metadata(train_data, valid_data, test_data, unlabel_data, target_col):
    feature_columns = [col for col in train_data.columns if col != target_col]
    categorical_columns = ["PRODUCT_ID", "PRODUCT_BODY", "RECIPE"]
    cat_idxs = [feature_columns.index(col) for col in categorical_columns if col in feature_columns]
    con_idxs = [idx for idx in range(len(feature_columns)) if idx not in cat_idxs]

    frames = [train_data, valid_data, test_data]
    if not unlabel_data.empty:
        frames.append(unlabel_data)
    all_features = pd.concat([frame[feature_columns] for frame in frames], ignore_index=True)

    cat_dims = []
    for col in categorical_columns:
        if col in all_features.columns:
            cat_dims.append(int(all_features[col].max()) + 1)

    return cat_dims, cat_idxs, con_idxs


def write_split(source_dir, output_root, ratio, target_col, time_column=None):
    train_path = source_dir / "smic_train.csv"
    unlabel_path = source_dir / "smic_unlabel.csv"
    valid_path = source_dir / "smic_valid.csv"
    test_path = source_dir / "smic_test.csv"

    train_data = pd.read_csv(train_path)
    unlabel_data = pd.read_csv(unlabel_path)
    valid_data = pd.read_csv(valid_path)
    test_data = pd.read_csv(test_path)

    if target_col not in train_data.columns:
        raise ValueError(f"Missing target column in train data: {target_col}")
    if target_col not in unlabel_data.columns:
        raise ValueError(
            f"Missing target column in source unlabel data: {target_col}. "
            "The source unlabel file must keep targets so ratios can be rebuilt."
        )

    pool_size = len(train_data) + len(unlabel_data)
    labeled_count = int(round(pool_size * ratio))
    labeled_count = max(1, min(labeled_count, pool_size))
    unlabel_count = pool_size - labeled_count
    valid_count = len(valid_data)
    test_count = len(test_data)

    # Reassemble all rows, sort once, then create four adjacent time blocks:
    # labeled train -> validation -> unlabeled train -> test.
    full_data = pd.concat(
        [train_data, valid_data, unlabel_data, test_data],
        ignore_index=True,
    )
    full_data, resolved_time_col = chronological_sort(full_data, time_column)

    train_end = labeled_count
    valid_end = train_end + valid_count
    unlabel_end = valid_end + unlabel_count
    test_end = unlabel_end + test_count
    split_train = full_data.iloc[:train_end].copy().reset_index(drop=True)
    valid_data = full_data.iloc[train_end:valid_end].copy().reset_index(drop=True)
    split_unlabel = full_data.iloc[valid_end:unlabel_end].copy().reset_index(drop=True)
    test_data = full_data.iloc[unlabel_end:test_end].copy().reset_index(drop=True)

    if resolved_time_col is not None:
        split_train = split_train.drop(columns=[resolved_time_col])
        valid_data = valid_data.drop(columns=[resolved_time_col])
        split_unlabel = split_unlabel.drop(columns=[resolved_time_col])
        test_data = test_data.drop(columns=[resolved_time_col])

    split_unlabel_features = split_unlabel.drop(columns=[target_col])

    dataset_name = ratio_to_name(ratio)
    output_dir = output_root / dataset_name
    output_dir.mkdir(parents=True, exist_ok=True)

    split_train.to_csv(output_dir / f"{dataset_name}_train.csv", index=False)
    valid_data.to_csv(output_dir / f"{dataset_name}_valid.csv", index=False)
    test_data.to_csv(output_dir / f"{dataset_name}_test.csv", index=False)
    split_unlabel_features.to_csv(output_dir / f"{dataset_name}_unlabel.csv", index=False)

    cat_dims, cat_idxs, con_idxs = infer_metadata(
        split_train, valid_data, test_data, split_unlabel_features, target_col
    )
    meta = {
        "cat_dims": cat_dims,
        "cat_idxs": cat_idxs,
        "con_idxs": con_idxs,
        "data_shape": {
            "train": list(split_train.shape),
            "valid": list(valid_data.shape),
            "test": list(test_data.shape),
            "unlabel": list(split_unlabel_features.shape),
        },
        "source_file": str(source_dir),
        "unlabel_processed": True,
        "categorical_encoding": "preprocessed_smic2",
        "target_scaled": True,
        "labeled_ratio": ratio,
        "split_strategy": CHRONOLOGICAL_SEMI_SUPERVISED_STRATEGY,
        "time_column": resolved_time_col or "source_order",
    }
    with (output_dir / f"{dataset_name}_meta.json").open("w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2)

    for optional_name in ["README.txt"]:
        optional_path = source_dir / optional_name
        if optional_path.exists():
            shutil.copy2(optional_path, output_dir / optional_name)

    print(
        f"{dataset_name}: labeled={len(split_train)}, "
        f"unlabeled={len(split_unlabel_features)}, output={output_dir}"
    )


def main():
    args = build_parser().parse_args()
    source_dir = Path(args.source_dir)
    output_root = Path(args.output_root)

    for ratio in args.ratios:
        if ratio <= 0 or ratio > 1:
            raise ValueError(f"Ratio must be in (0, 1], got {ratio}")
        write_split(
            source_dir,
            output_root,
            ratio,
            args.target_col,
            time_column=args.time_column,
        )


if __name__ == "__main__":
    main()
